/*
 * Created on Feb 22, 2006
 */
package com.iadmin.portal.module;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import catalog.Catalog;
import catalog.constant.Constant;
import catalog.controller.Controller;
import catalog.model.GlobalSessionBean;

import com.iadmin.portal.constant.ServiceConst;
import com.iadmin.portal.security.UserSession;
/**
 * @author james.yong
 */
public final class SSOLogin extends Controller implements ServiceConst {
	
	 private static final String PORTAL="portal";
	 private static final String ELEAVE="eLeave";
	 private static final String ECLAIM="eClaim";
	 private static final String STAFFADMIN="StaffAdmin";
	 private static final String EMEMO="eMemo";
	 private static final String ESURVEY="eSurvey";
	 private static final String EPAYROLL="ePayroll";
	 private static final String ETIMESHEET="eTimeSheet";
	 private static final String EUPDATE="eUpdate";
	 private static final String EREFERENCE="eReference";
	 private static final String ETAX = "eTax";
	 private static final String CALENDAR = "calendar";
	 private static final String ACCESSCONTROL = "accesscontrol";
	 private static final String USER = "user";
	 private static final String EREGISTRATION="eRegistration";
	 private static final String ETAXFORM="eTaxform";
	 private static final String ETEMPLATE="etemplate";
	 private static final String REMOTEUSER="remoteuser";   
	 //not yet in use
	 private static final String HIRINGADMIN="HiringAdmin";
	 private static final String PAYADMIN="PayAdmin";
	 private static final String EPAYSLIP="ePaySlip";
	 private static final String REPORTADMIN="ReportAdmin";
	    
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
       Catalog.setRedirect("/catalog?module=SSOLogin&cmd=appendTicket&app="+request.getParameter("app"));
       return "";
	}
	
	//append a ticket to the url
	public String appendTicket() throws IOException {
		
		HttpServletRequest request = Catalog.getRequest();
		HttpServletResponse response = Catalog.getResponse();
		
		HttpSession session = request.getSession();
	       
	    String app = request.getParameter("app");
	    		
    	//get Links to applications
        String leaveadmin_link = (String)session.getAttribute(LEAVEADMIN_LINK);
        String staffadmin_link = (String)session.getAttribute(STAFFADMIN_LINK);
   	    String eclaim_link = (String)session.getAttribute(ECLAIM_LINK);
   	    String ememo_link = (String)session.getAttribute(EMEMO_LINK);
   	    String esurvey_link = (String)session.getAttribute(ESURVEY_LINK);
   	    String epayroll_link = (String)session.getAttribute(EPAYROLL_LINK);
   	    String etimesheet_link = (String)session.getAttribute(ETIMESHEET_LINK);
   	    String eupdate_link = (String)session.getAttribute(EUPDATE_LINK);
   	    String epayslip_link = (String)session.getAttribute(EPAYSLIP_LINK);
   	    String hiringadmin_link = (String)session.getAttribute(HIRINGADMIN_LINK);
	    String payadmin_link = (String)session.getAttribute(PAYADMIN_LINK);
	    String ereference_link = (String)session.getAttribute(EREFERENCE_LINK);
	    String etax_link = (String)session.getAttribute(ETAX_LINK);
	    String calendar_link = (String)session.getAttribute(CALENDAR_LINK);
	    String accesscontrol_link = (String)session.getAttribute(ACCESSCONTROL_LINK);
	    String user_link = (String)session.getAttribute(USER_LINK);
	    String eregistration_link = (String)session.getAttribute(EREGISTRATION_LINK);
	    String etaxform_link = (String)session.getAttribute(ETAXFORM_LINK);
	    String etemplate_link = (String)session.getAttribute(ETEMPLATE_LINK);
		String remoteuser_link = (String)session.getAttribute(REMOTEUSER_LINK);
		String reportadmin_link = (String)session.getAttribute(REPORTADMIN_LINK);
			
    	GlobalSessionBean gsbean = new GlobalSessionBean();
    	gsbean.setApp_name(PORTAL);
    	gsbean.setSession_id(session.getId());
    	
    	System.out.println("app="+app);
    	System.out.println("epayroll_link="+epayroll_link);
	    	
        if(app.equalsIgnoreCase(ELEAVE)){     
	    	response.sendRedirect(leaveadmin_link+"module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(LEAVEADMIN_DB));
	    }
	    else if(app.equalsIgnoreCase(ECLAIM)){ //actually used for eClaim now
	        response.sendRedirect(eclaim_link+"event=SSOLOGIN");
	    }
	    else if(app.equalsIgnoreCase(STAFFADMIN)){
			response.sendRedirect(staffadmin_link);
	    }
	    else if(app.equalsIgnoreCase(EMEMO)){
	    	//response.sendRedirect(ememo_link+"event=SSOLOGIN");
	    	response.sendRedirect(ememo_link+"module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(EMEMO_DB));
	    }
	    else if(app.equalsIgnoreCase(ESURVEY)){
	    	response.sendRedirect(esurvey_link+"module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(ServiceConst.ESURVEY_DB));
	    }
	    else if(app.equalsIgnoreCase(EPAYROLL)){
	    	System.out.println("Going to epayroll");
	    	Catalog.setNewContextPath( epayroll_link );
	    	Catalog.setRedirect( "module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(ServiceConst.EPAYROLL_DB) );
	    	//response.sendRedirect(epayroll_link+"module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(ServiceConst.EPAYROLL_DB));
	    }
        else if(app.equalsIgnoreCase(ETIMESHEET)){ 
	        response.sendRedirect(etimesheet_link+"event=SSOLOGIN");
	    }
        else if(app.equalsIgnoreCase(EPAYSLIP)){// Task ID : 5186 appednde language from catalog session to get it into etaxform 
        	response.sendRedirect(epayslip_link+"event=SSOLOGIN&db_name="+session.getAttribute(ServiceConst.EPAYSLIP_DB)+"&lang="+session.getAttribute(Constant.SESSION_LANG)); // Amit Kumar
        }
        else if(app.equalsIgnoreCase(EUPDATE)){
        	response.sendRedirect(eupdate_link+"module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(ServiceConst.EUPDATE_DB));
        }
        else if(app.equalsIgnoreCase(EREFERENCE)){
        	response.sendRedirect(ereference_link+"module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(ServiceConst.EREFERENCE_DB));
        }
        else if(app.equalsIgnoreCase(ETAX)){
        	response.sendRedirect(etax_link+"module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(ServiceConst.ETAX_DB));
        	//response.sendRedirect(etax_link+"event=SSOLOGIN");
        }
        else if(app.equalsIgnoreCase(CALENDAR)){
        	String out = calendar_link+"module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(ServiceConst.CALENDAR_DB);
        	System.out.println(out);
        	response.sendRedirect( out );
        }
        else if(app.equalsIgnoreCase(ACCESSCONTROL)){
        	response.sendRedirect(accesscontrol_link+"module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(ServiceConst.ACCESSCONTROL_DB));
        }
        else if(app.equalsIgnoreCase(USER)){
        	String out = user_link+"module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(ServiceConst.USER_DB);
        	System.out.println(out);
        	response.sendRedirect(user_link+"module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(ServiceConst.USER_DB));
        }
        else if(app.equalsIgnoreCase(ETEMPLATE)){
        	String out = etemplate_link+"module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(ServiceConst.ETEMPLATE_DB);
        	System.out.println(out);
        	response.sendRedirect(etemplate_link+"module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(ServiceConst.ETEMPLATE_DB));
        }
        else if(app.equalsIgnoreCase(EREGISTRATION)){
        	String out = eregistration_link+"module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(ServiceConst.EREGISTRATION_DB);
        	System.out.println(out);
        	response.sendRedirect(eregistration_link+"module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(ServiceConst.EREGISTRATION_DB));
        }
        else if(app.equalsIgnoreCase(ETAXFORM)){// Amit Kumar appednde language from catalog session to get it into etaxform 
        	String out = etaxform_link+"module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(ServiceConst.ETAXFORM_DB)+"&lang="+session.getAttribute(Constant.SESSION_LANG);
        	System.out.println(out);
        	response.sendRedirect(etaxform_link+"module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(ServiceConst.ETAXFORM_DB)+"&lang="+session.getAttribute(Constant.SESSION_LANG));
		}
        else if(app.equalsIgnoreCase(REMOTEUSER)){
        	String out = remoteuser_link+"module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(ServiceConst.REMOTEUSER_DB);
        	System.out.println(out);
        	response.sendRedirect(remoteuser_link+"module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(ServiceConst.REMOTEUSER_DB));
        }
        else if(app.equalsIgnoreCase(REPORTADMIN)){
        	String out = reportadmin_link+"module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(ServiceConst.REPORTADMIN_DB);
        	System.out.println(out);
        	response.sendRedirect(reportadmin_link+"module=Login&cmd=SSOLogin&POOL_NAME="+session.getAttribute(ServiceConst.REPORTADMIN_DB));
        }
        else {
        	System.out.println("SSO not working!");
        	//Need to inform web user that SSO is not working and to disable the
        	//GOTO buttons
        }
        //invalidate the session before redirect
       // session.invalidate();
        return "";
	}

}


