package epayslip.system.event;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import catalog.constant.Constant;
import catalog.utility.CR;

import sun.misc.BASE64Encoder;
import epayslip.db.EpayslipUserList;
import epayslip.db.User;
import epayslip.db.init.ConnectionPool;
import epayslip.system.EPaySlipController;
import epayslip.utility.ConfigUtil;

public class ViewEventHandler_list extends EventHandler {

	public final static int BUF_SIZE = 500;

	private ResourceBundle bundle = ResourceBundle.getBundle("URLs");
	ResourceBundle rb;

	
	/*private String[] month_value= { "admin.j", "February", "March", "April",
			"May", "June", "July", "August", "September", "October",
			"November", "December" };*/


	protected String getURL() {
		return bundle.getString("");
	}

	public void process(ServletContext sc, HttpServletRequest request,
			HttpServletResponse response) throws IOException, ServletException {
		
		
		System.out.println("===============into ViewEventHandler_list > process()===============");
		 // Task ID : 5186 geting language from request 
		HttpSession session = request.getSession();
		String localLan = (String)request.getSession().getAttribute(User.LOCAL);
		rb = ResourceBundle.getBundle(localLan);//amit Task ID : 5186 
		response.setCharacterEncoding("UTF-8"); // amit Task ID : 5186 
		 // Task ID : 5186 end
		String[] month_value= { rb.getString("epayslip.January"), rb.getString("epayslip.February"), rb.getString("epayslip.March"), rb.getString("epayslip.April"),
				rb.getString("epayslip.May"), rb.getString("epayslip.June"), rb.getString("epayslip.July"), rb.getString("epayslip.August"), rb.getString("epayslip.September"), rb.getString("epayslip.October"),
				rb.getString("epayslip.November"), rb.getString("epayslip.December") };


		PrintWriter out = response.getWriter();
		StringBuffer HTML = new StringBuffer();

		Calendar cal = Calendar.getInstance();
		String currentMonth = String.valueOf(cal.get(Calendar.MONTH) + 1);
		if (currentMonth.length() == 1)
			currentMonth = "0" + currentMonth;

		String comId, year, month, condition = "id", value = "", eready = "2";

		comId = (String) session.getAttribute(User.LOGIN_COMID);
		year = request.getParameter("year");
		month = request.getParameter("month");
		if (month == null)
			month = (String) session.getAttribute("currentmonth");

		boolean html_pdf = ConfigUtil.getPdfFlag(year, month, request);

		if (html_pdf) {
			session.setAttribute("currentmonth", month);
		}

		session.setAttribute("currentyear", year);
		if (month != null) {
			if (month.indexOf("0") >= 0 && month.indexOf("0") != 1) {
				session.setAttribute("currentmonth", month.substring(1, 2));
			} else {
				session.setAttribute("currentmonth", month);
			}
		}

		if (month.length() == 1) {
			month = "0" + month;
		}

		/**
		 * visent.30Mar09 for clients that not epayroll module
		 */

		String lnTag = "\n";

		// start of the epayslip list of all the employee
		HTML.append("<html>");
		HTML.append(lnTag);
		HTML.append("<head>");
		HTML.append(lnTag);
	/*	HTML.append("<title>E-Payslip</title>");*/
	
		HTML.append("<meta http-equiv='Content-Type' content='text/html; charset=ISO-8859-1'>");
		String titalsLang = rb.getString("eayslip.tan.title");	
		HTML.append("<title>"+rb.getString("eayslip.tan.title")+"</title>");
		HTML.append(lnTag);
		//HTML
		//.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">");
		HTML.append("<meta http-equiv=\"X-UA-Compatible\" content=\"IE=8,chrome=1\">");
		HTML.append(lnTag);
		
		/*HTML.append("<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>");
		HTML.append("<script src='//code.jquery.com/jquery-1.10.2.js'></script>");
		HTML.append("<script src='//code.jquery.com/ui/1.11.4/jquery-ui.js'></script>");
		HTML.append("<link rel='stylesheet' href='/resources/demos/style.css'>");*/
		
		HTML.append("<link rel='stylesheet' href='/epayslip/jquery-ui.css'>");
		HTML.append("<script src='/epayslip/jquery-1.9.1.js'></script>");
		HTML.append("<script src='/epayslip/jquery-ui.js'></script>");
		//HTML.append("<link rel='stylesheet' href='/resources/demos/style.css'>");
		
		
		
		HTML
				.append("<link rel='stylesheet' href='/epayslip/bg.css' type='text/css'>");
		HTML.append(lnTag);
		HTML
				.append("<link rel='stylesheet' href='/epayslip/text.css' type='text/css'>");
		HTML.append(lnTag);
		HTML.append("<style>");
		HTML.append(lnTag);
		HTML.append("A:link {text-decoration:none; color:#FF9900; }");
		HTML.append(lnTag);
		HTML.append("A:visited {text-decoration:none; color:#FF9900; }");
		HTML.append(lnTag);
		HTML.append("A:hover	{text-decoration:none; color:#bbbbbb");
		HTML.append(lnTag);
		HTML.append("</style>");
		HTML.append(lnTag);
		HTML.append("<script language=JavaScript>");
		HTML.append("function callBack(name){");
		HTML.append("window.parent.returnValue = name;");
		HTML.append("window.parent.close();");
		HTML.append("}");
		HTML.append("function callBack2(){");
		HTML.append("var name = '';");
		HTML.append("var robj = document.getElementsByName('for');");
		HTML.append("for(i=0;i<robj.length;i++){");
		HTML.append("var subobj = robj[i];");
		HTML.append("if(subobj.checked){");
		HTML.append("name = subobj.value;");
		HTML.append("break;");
		HTML.append("}");
		HTML.append("}");
		HTML.append("if(name != ''){");
		HTML.append("document.pdfdownload.dtype.value = name;");
		HTML.append("document.pdfdownload.submit();");
		HTML.append("$('#dialog').dialog('close')");
		HTML.append("}else{");
		HTML.append("alert('Please select an option!');");
		HTML.append("}");
		HTML.append("}");
		HTML.append(lnTag);
		
			  // next add the onclick handler
				
		/*HTML.append("$(document).delegate('#simplestring', 'click', function() {");
		HTML.append("$(this).simpledialog({");
		HTML.append("'mode' : 'string',");
		HTML.append("'prompt' : 'What do you say?',");
		HTML.append("'buttons' : {");
		HTML.append("'OK': {");
		HTML.append("click: function () {");
		HTML.append("$('#dialogoutput').text($('#dialoglink').attr('data-string'));");
		HTML.append("}");
		HTML.append("},");
		HTML.append("'Cancel': {");
		HTML.append("click: function () { },");
		HTML.append("icon: 'delete',");
		HTML.append("theme: 'c'");
		HTML.append("}");
		HTML.append("}");
		HTML.append("})");
		HTML.append("})");*/
		
			    
			    
		/*	    
		HTML.append("$('#contactUs').click(function()");
		HTML.append("{$('#dialog').dialog('open')}"); 
		*/
		
		
		HTML.append("function nextPage(d) {");
		HTML.append(lnTag);
		HTML.append("	document.formOwn.page.value=d;");
		HTML.append(lnTag);
		/**
		 * HTML.append("	var chkBox = document.getElementsByName('CHECKBOX');");
		 * HTML.append(lnTag); HTML.append(
		 * "	var num = document.getElementsByName('CHECKBOX').length;");
		 * HTML.append(lnTag); HTML.append("	for (i = 0; i < num; i++) {");
		 * HTML.append(lnTag); HTML.append("		if (chkBox[i].checked && document.formOwn.checked.value.indexOf(chkBox[i].value) < 0) {"
		 * ); HTML.append(lnTag);
		 * HTML.append("			//alert('to add: ' + chkBox[i].value);");
		 * HTML.append(lnTag); HTML.append(
		 * "			document.formOwn.checked.value += ('$' + chkBox[i].value);");
		 * HTML.append(lnTag); HTML.append("		} else if (!chkBox[i].checked && document.formOwn.checked.value.indexOf(chkBox[i].value) >= 0) {"
		 * ); HTML.append(lnTag);
		 * HTML.append("			//alert('to deduce: ' + chkBox[i].value);");
		 * HTML.append(lnTag); HTML.append("			document.formOwn.checked.value = document.formOwn.checked.value.replace('$'+chkBox[i].value, '');"
		 * ); HTML.append(lnTag); HTML.append("			document.formOwn.checked.value = document.formOwn.checked.value.replace(chkBox[i].value, '');"
		 * ); HTML.append(lnTag); HTML.append("		}"); HTML.append(lnTag);
		 * HTML.append("	}"); HTML.append(lnTag);
		 */
		HTML.append("	document.formOwn.submit();");
		HTML.append(lnTag);
		HTML.append("}");
		HTML.append(lnTag);

		HTML.append("function closeMe()").append(lnTag);
		HTML.append("{").append(lnTag);
		// Task ID : 5186 confirmation 
		HTML.append("    var conf = confirm('"+ rb.getString("epayslip.confirm.logout") +"');").append(lnTag);
		HTML.append("    if (conf)").append(lnTag);
		HTML.append("        document.logout.submit();").append(lnTag);
		HTML.append("}").append(lnTag);

		HTML.append("function find() {");
		HTML.append(lnTag);
		HTML.append("	document.formSearch.submit();");
		HTML.append(lnTag);
		HTML.append("}");
		HTML.append(lnTag);

		HTML.append("function find1(size) {");
		HTML.append(lnTag);
		HTML.append("if(size == 10000){");
		HTML.append("	document.formOwn.page.value = 1;");
		HTML.append("}");
		HTML.append("	document.formOwn.maxsize.value=size;");
		HTML.append(lnTag);
		/**
		 * HTML.append("	var chkBox = document.getElementsByName('CHECKBOX');");
		 * HTML.append(lnTag); HTML.append(
		 * "	var num = document.getElementsByName('CHECKBOX').length;");
		 * HTML.append(lnTag); HTML.append("	for (i = 0; i < num; i++) {");
		 * HTML.append(lnTag); HTML.append("		if (chkBox[i].checked && document.formSearch.checked.value.indexOf(chkBox[i].value) < 0) {"
		 * ); HTML.append(lnTag);
		 * HTML.append("			//alert('to add: ' + chkBox[i].value);");
		 * HTML.append(lnTag); HTML.append(
		 * "			document.formSearch.checked.value += ('$' + chkBox[i].value);");
		 * HTML.append(lnTag); HTML.append("		} else if (!chkBox[i].checked && document.formSearch.checked.value.indexOf(chkBox[i].value) >= 0) {"
		 * ); HTML.append(lnTag);
		 * HTML.append("			//alert('to deduce: ' + chkBox[i].value);");
		 * HTML.append(lnTag); HTML.append("			document.formSearch.checked.value = document.formSearch.checked.value.replace('$'+chkBox[i].value, '');"
		 * ); HTML.append(lnTag); HTML.append("			document.formSearch.checked.value = document.formSearch.checked.value.replace(chkBox[i].value, '');"
		 * ); HTML.append(lnTag); HTML.append("		}"); HTML.append(lnTag);
		 * HTML.append("	}"); HTML.append(lnTag);
		 */
		HTML.append("	document.formOwn.submit();");
		HTML.append(lnTag);
		HTML.append("}");
		HTML.append(lnTag);

		HTML.append("function backToStart() {");
		// if(html_pdf){
		// session.setAttribute( "maxsize", null );
		// }
		HTML.append(lnTag);
		HTML.append("	document.backToStart.submit();");
		HTML.append(lnTag);
		HTML.append("}");
		HTML.append(lnTag);

		HTML.append("function openReadWindow(link) {");
		HTML.append(lnTag);
		HTML
				.append("	var wind = window.open(link,null,'width=800,height=600,toolbar=0,location=0,menubar=0,scrollbars=1,resizable=1');");
		HTML.append(lnTag);

		HTML.append("}");
		HTML.append(lnTag);

		HTML.append("function checkall(){");
		HTML.append(lnTag);
		HTML.append("	var ca = document.getElementsByName('checkall');");
		HTML.append(lnTag);
		HTML.append("	if(ca[0].checked){");
		HTML.append(lnTag);
		HTML
				.append("		var selects = document.getElementsByName(\"CHECKBOX\");");
		HTML.append(lnTag);
		HTML.append("		for(var i = 0 ; i <selects.length;i++){");
		HTML.append(lnTag);
		HTML.append("			selects[i].checked=\"checked\";");
		HTML.append(lnTag);
		HTML.append("		}");
		HTML.append(lnTag);
		HTML.append("	}else{");
		HTML.append(lnTag);
		HTML
				.append("		var selects = document.getElementsByName(\"CHECKBOX\");");
		HTML.append(lnTag);
		HTML.append("		for(var i = 0 ; i <selects.length;i++){");
		HTML.append(lnTag);
		HTML.append("			selects[i].checked=\"\";");
		HTML.append(lnTag);
		HTML.append("		}");
		HTML.append(lnTag);
		HTML.append("	}");
		HTML.append(lnTag);
		HTML.append("}");
		HTML.append(lnTag);

		HTML.append("function download(){");
		HTML.append(lnTag);
		HTML.append("   document.pdfdownload.selectedid.value='';");
		HTML.append(lnTag);
		HTML.append("	var chkBox = document.getElementsByName('CHECKBOX');");
		HTML.append(lnTag);
		HTML
				.append("	var num = document.getElementsByName('CHECKBOX').length;");
		HTML.append(lnTag);
		HTML.append("	for (i = 0; i < num; i++) {");
		HTML.append(lnTag);
		HTML.append("		if (chkBox[i].checked) {");
		HTML.append(lnTag);
		HTML
				.append("		  document.pdfdownload.selectedid.value += (',' + chkBox[i].value);");
		HTML.append(lnTag);
		HTML.append("		  //chkBox[i].value='';");
		HTML.append(lnTag);
		HTML.append("		}");
		HTML.append(lnTag);
		HTML.append("	}");
		HTML.append(lnTag);
		HTML.append("	if(document.pdfdownload.selectedid.value == ''){");
		HTML.append(lnTag);// Task ID 5186 must select one employee!
		HTML.append("		alert('"+ rb.getString("epayslip.must.select.employee") +"');");
		HTML.append(lnTag);
		HTML.append("	}else{");
		HTML.append(lnTag);
		/*HTML
		.append("		var strReturnValue = window.showModalDialog(\"../dialogPage.jsp\", \'\' ,\"dialogHeight:220px;dialogWidth:350px;center=yes\");");
		HTML.append(lnTag);
		HTML.append("		if(strReturnValue != undefined){");
		HTML.append(lnTag);
		HTML.append("			document.pdfdownload.dtype.value = strReturnValue");
		HTML.append(lnTag);
		HTML.append("			document.pdfdownload.submit();");
		HTML.append(lnTag);
		HTML.append("		}");
		HTML.append(lnTag);*/
		HTML.append("$( '#dialog' ).dialog({width:'auto',resizable: false,height: 250}) ");
		HTML.append(lnTag);
		//HTML.append("			document.pdfdownload.dtype.value = strReturnValue");
		//HTML.append(lnTag);
		//HTML.append("			document.pdfdownload.submit();");
		HTML.append("	}");
		HTML.append(lnTag);
		HTML.append("};");
		HTML.append(lnTag);
		//==========================================================↓ henry 19,April 2012==========================================================
		HTML.append("function upload(){");
		HTML.append(lnTag);
//		HTML.append("var getv = showModalDialog(\"../dialogPage4Upload.jsp\", \"\", \"dialogWidth:900px; dialogHeight:400px;status:no;help:yes\");");
		HTML.append("document.getElementById('uploaddiv').style.display='block';");
		HTML.append(lnTag);
		HTML.append("}");
		HTML.append(lnTag);
		
		HTML.append("function doUpload(){");
		HTML.append(lnTag);
		HTML.append("	var checkflag = form_check();");
		HTML.append(lnTag);
		HTML.append("	document.getElementById('uploadform').action='#';	");
		HTML.append(lnTag);
		HTML.append("if(checkflag){");
		HTML.append(lnTag);
		HTML.append("		document.getElementById('uploadform').action='/epayslip/servlet/EPSController?event=UPLOAD';	");
		HTML.append(lnTag);
		HTML.append("		document.getElementById('uploadform').submit();");
		HTML.append(lnTag);
		HTML.append("	}");
		HTML.append(lnTag);
		HTML.append("	return false;");
		HTML.append(lnTag);
		HTML.append("}");
		HTML.append(lnTag);
		
		HTML.append(lnTag);
		HTML.append("function form_check(){");
		HTML.append(lnTag);
		HTML.append("	var fileName = document.getElementById('fileupload').value;");
		HTML.append(lnTag);
		HTML.append("	var extension = /(\\.zip)$/");
		HTML.append(lnTag);
		HTML.append("	if (fileName == '') {");
		HTML.append(lnTag);//Task ID: 5186 Please select a file.
		HTML.append("		alert('"+ rb.getString("epayslip.plz.select.file") +"');");
		HTML.append(lnTag);
		HTML.append("		return false;");
		HTML.append(lnTag);
		HTML.append("	}");
		HTML.append(lnTag);
		HTML.append("	else if (!extension.test(fileName)) {");
		HTML.append(lnTag);//Task ID : 5186 You can only upload a zip 
		HTML.append("		alert('"+ rb.getString("epayslip.zip.upload.file") +"');");
		HTML.append(lnTag);
		HTML.append("		return false;");
		HTML.append(lnTag);
		HTML.append("	}");
		HTML.append(lnTag);
		HTML.append("	else ");
		HTML.append(lnTag);
		HTML.append("		return true;");
		HTML.append(lnTag);
		HTML.append("}");
		HTML.append(lnTag);
		
		
		//==========================================================↑ henry 19,April 2012==========================================================
		HTML.append("function detail(a, b, c, d) {");
		HTML.append(lnTag);
		HTML.append("	document.epayslip.check.value = a;");
		HTML.append(lnTag);
		HTML.append("	document.epayslip.theYear.value = b;");
		HTML.append(lnTag);
		HTML.append("	document.epayslip.theMonth.value = c;");
		HTML.append(lnTag);
		HTML.append("	document.epayslip.page.value = d;");
		HTML.append(lnTag);
		HTML.append("	document.epayslip.submit();");
		HTML.append(lnTag);
		HTML.append("}");
		HTML.append(lnTag);

		HTML.append("function MM_preloadImages() {");
		HTML
				.append("	var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();");
		HTML
				.append("	var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)");
		HTML
				.append("if (a[i].indexOf('#')!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}");
		HTML.append("}");

		HTML.append("function doAdviceSubmit(tempVar){");
		HTML.append("	document.adviceForm.pid.value = tempVar.id;");
		HTML.append("	document.adviceForm.submit();");
		HTML.append("}");

		HTML.append("</script>");
		HTML.append(lnTag);
		HTML.append("</head>");
		HTML.append(lnTag);

		HTML
				.append("<body onload=\"MM_preloadImages('../images/view_over.gif','../images/view.gif')\" bgcolor='#FFFFFF' text='#000000' class='BG'>");
		HTML.append(lnTag);
		
		HTML.append("<div id='dialog' class='hidden-true-test' title='"+ rb.getString("epayslip.download.pdf1") +"'>");
		/*HTML.append("<p>This is the default dialog which is useful for displaying information. The dialog window can be moved, resized and closed with the 'x' icon.</p>");*/
		dialogPage(HTML);
		HTML.append("</div>");
		
		
		
		/*HTML.append("<p>You have entered: <span id='dialogoutput'></span></p>");

		HTML.append("<a href='#' id='dialoglink' data-role='button'>Open Dialog</a>");*/
		
		
		
		/*HTML.append("<a href='#' id='contactUs'>Contact Us</a>");                   
		HTML.append("<div id='dialog' title='Contact form'>");
        HTML.append("<p>appear now</p>");
        HTML.append("</div>");*/
		// User usr = EPaySlipController.getUserManager();
		EpayslipUserList epayslipUserList = EPaySlipController
				.getEpayslipUserList();

		try {
			int pagenum = 1;
			if (request.getParameter("page") != null) {
				pagenum = Integer.parseInt(request.getParameter("page"));
			}
			if (request.getParameter("condition") != null) {
				condition = request.getParameter("condition");
			}
			if (request.getParameter("value") != null) {
				value = request.getParameter("value").trim();
				/**
				 * Visent 6Apr2011
				 * security:
				 * if user keyin below condition for search, then can show Anonymous use.
				 *  """s' UNION SELECT null,username FROM all_users --"""
				 */
				if(CR.isNNNE(value)){
					String[] disAllow = {" union "," select "," from "};
					for(String item: disAllow){
						if(value.toLowerCase().indexOf(item) > -1){
							value = "";
							break;
						}
					}
				}
				/** end */
			}
			if (request.getParameter("eready") != null) {
				eready = request.getParameter("eready").trim();
			}
			request.setAttribute("CONDITION", condition);
			request.setAttribute("VALUE", value);
			request.setAttribute("eready", eready);

			Vector listOfEpayslip = epayslipUserList.getAllEpayslipEmployee(
					comId, condition, value, eready, request);

			int maxsize = 10;
			// modified by zhou for user's favorite of num of page 01Apr 2008
			if (request.getParameter("maxsize") != null
					&& !request.getParameter("maxsize").equals("")) {
				maxsize = Integer.valueOf(request.getParameter("maxsize"));
				session.setAttribute("maxsize", maxsize);
			}
			if (session.getAttribute("maxsize") != null) {
				maxsize = Integer.valueOf(session.getAttribute("maxsize")
						.toString());
			}

			int pages = (listOfEpayslip.size()) / maxsize;
			int pageid = 1;
			int remainder = (listOfEpayslip.size()) % maxsize;

			if (remainder != 0) {
				pages++;
			}

			// from index m to n of the list of some page id
			int m, n;
			m = (pagenum - 1) * maxsize;
			if (pagenum == pages) {
				n = listOfEpayslip.size();
			} else {
				n = pagenum * maxsize;
			}

			// title
			HTML.append("<div align='center'>").append(lnTag);
			HTML
					.append(
							"	<table width='610' border='0' cellspacing='0' cellpadding='0' height='92'>")
					.append(lnTag);
			HTML.append("		<tr>").append(lnTag);

			String imgPath = request.getRealPath("") + File.separator
					+ "images" + File.separator + comId + ".gif";
			File imgFile = new File(imgPath);
			if (!imgFile.exists()) {
				HTML.append("			<td width='155'><img src='/epayslip/images/epaysmal.gif' width='146' height='92'></td>").append(lnTag);
			} else {
				HTML.append("			<td width='155'><img src='/epayslip/images/"+ comId+ ".gif'></td>")
						.append(lnTag);
			}

			HTML
					.append(
							"			<td width='455'><img src='/epayslip/images/topbar.jpg' width='455' height='92'></td>")
					.append(lnTag);
			HTML.append("		</tr>").append(lnTag);
			HTML.append("	</table>").append(lnTag);
			HTML.append("</div>").append(lnTag);

			// header Task ID : 5186 for heading info 
			HTML.append("<br>");
			HTML
					.append("  <table width='600' border='0' cellspacing='0' cellpadding='5' align='center' height='40'>");
			HTML.append(lnTag);
			HTML.append("    <tr>");
			HTML.append(lnTag);
			HTML
					.append("      <td background='/epayslip/images/blank_bar.gif' valign='bottom'>"
							+ "<font color='#FFFFFF' face='Arial, Helvetica, sans-serif' size='3'><b>  " + rb.getString("epayslip.of.all.employee") + "</b></font>");
			HTML.append(lnTag);
			HTML.append("      </td>");
			HTML.append(lnTag);
			HTML
					.append("      <td bgcolor='#003366' valign='bottom' align='right'>"
							+ "<font color='#FFFFFF' face='Arial, Helvetica, sans-serif' size='3'><b>"
							+ month_value[Integer.parseInt(month) - 1]
							+ "&nbsp&nbsp" + year + "</b></font>");
			HTML.append(lnTag);
			HTML.append("      </td>");
			HTML.append(lnTag);
			HTML.append("    </tr>");
			HTML.append(lnTag);
			HTML.append("  </table>");

			// column header information
			HTML
					.append("  <table align=center width=600 border=1 cellspacing=0 cellpadding=0>");
			HTML.append(lnTag);
			HTML.append("     <tr bgcolor='#CCCCCC' height=24 vlign=middle>");
			HTML.append(lnTag);
			// header Task ID : 5186 for employe ID, Name and View 
			HTML.append("         <td align='center'><font face='Arial, Helvetica, sans-serif' size='2'>" + rb.getString("epayslip.employee.id") +"</font></td>");
			HTML.append(lnTag);
			//HTML.append("         <td align='center' colspan=2><font face='Arial, Helvetica, sans-serif' size='2'>Employee Name</font></td>");
			HTML.append("         <td align='center' colspan=2><font face='Arial, Helvetica, sans-serif' size='2'>" + rb.getString("epayslip.employee.name") +"</font></td>");
			HTML.append(lnTag);

			// HTML.append("         <td align='center'><font face='Arial, Helvetica, sans-serif' size='2'>Surname</font></td>");
			// HTML.append(lnTag);
			// HTML.append("         <td align='center'><font face='Arial, Helvetica, sans-serif' size='2'>Given Name</font></td>");
			// HTML.append(lnTag);
			//HTML.append("         <td align='center'><font face='Arial, Helvetica, sans-serif' size='2'>View</font></td>");
			HTML.append("         <td align='center'><font face='Arial, Helvetica, sans-serif' size='2'>" + rb.getString("epayslip.employee.view") +"</font></td>");
			HTML.append(lnTag);
			if (html_pdf) {
				//HTML.append("         <td align='center'><font face='Arial, Helvetica, sans-serif' size='2'>Download</font><input type=\"checkbox\" name=\"checkall\" onclick=\"checkall();\"></td>");
				HTML.append("         <td align='center'><font face='Arial, Helvetica, sans-serif' size='2'>" + rb.getString("epayslip.employee.download") +"</font><input type=\"checkbox\" name=\"checkall\" onclick=\"checkall();\"></td>");
				HTML.append(lnTag);
			}
			HTML.append("     </tr>");
			HTML.append(lnTag);

			String checked = "------";
			if (request.getParameter("checked") != null
					&& !request.getParameter("checked").equals("")) {
				checked = request.getParameter("checked");
				session.setAttribute("checked", checked);
			}
			if (session.getAttribute("checked") != null) {
				checked = session.getAttribute("checked").toString();
			}
			/**
			 * System.out.println("==================================================================================="
			 * ); System.out.println("to add to zip:   " + checked);
			 * System.out.println("==================================================================================="
			 * );
			 */
			// if no record found , notice HR
			if (listOfEpayslip.size() == 0) {
				HTML.append("    <tr>");
				HTML.append(lnTag);
				HTML.append("      <td height=24 colspan=5 align=center><font color='#ff0000' face='Arial, Helvetica, sans-serif' size='2'>"+ "" + rb.getString("epayslip.employee.download") +"</font>");
				HTML.append(lnTag);
				HTML.append("      </td>");
				HTML.append(lnTag);
				HTML.append("    </tr>");
				HTML.append(lnTag);
			} else {

				// display records of the page id
				for (int i = m; i < n; i++) {

					String[] all = (String[]) listOfEpayslip.elementAt(i);

					String empid = all[0];
					String empname = all[1];

					if (i % 2 == 0) {
						HTML
								.append("  <tr bgcolor='#FFFFFF' height=24 vlign=middle>");
					} else {
						HTML
								.append("  <tr bgcolor='#eeeeee' height=24 vlign=middle>");
					}
					HTML.append(lnTag);
					HTML
							.append("         <td width='20%'><font face='Arial, Helvetica, sans-serif' size='2'>&shy;"
									+ empid + "</font></td>");
					HTML.append(lnTag);
					HTML
							.append("         <td width='50%' colspan=2><font face='Arial, Helvetica, sans-serif' size='2'>&shy;"
									+ empname + "</font></td>");
					HTML.append(lnTag);
					/*
					 * HTML.append("         <td width='25%'><font face='Arial, Helvetica, sans-serif' size='2'>&shy;"
					 * + empsur + "</font></td>"); HTML.append(lnTag);
					 * HTML.append(
					 * "         <td width='25%'><font face='Arial, Helvetica, sans-serif' size='2'>&shy;"
					 * + empgiven + "</font></td>"); HTML.append(lnTag);
					 */
					boolean isAdvice = false;
					// modify by visnet.xie on 07May2008
					if (html_pdf) {
						// added by kevin for MPF/ORSO Advice Form on 9Feb 2011
						// start
						User usrMgr = EPaySlipController.getUserManager();
						String client_name = (String) session
								.getAttribute(User.LOGIN_COMID);
//						Hashtable ht = usrMgr.getUserInfoByPidAndClientid(
//								empid, client_name, false, request);
						String root, fullPath = "", sep, fileName = "";
						sep = File.separator; // platform dependent file
												// separator
						root = EPaySlipController.getDocRoot(); // Get the root
																// directory
						if (!root.substring(root.length() - 1).equals(
								File.separator)) {
							root = root + File.separator;
						}
						String dob = getDob(empid, request);
						fileName = "MPF_ORSO_" + empid + "_" + dob + "_" + year
								+ "_" + month + ".pdf";
						fullPath = root + client_name + sep + year + sep
								+ month + sep + "MPF_ORSO" + sep + fileName;
						File adviceFile = new File(fullPath + ".encrypted");
						if (adviceFile.exists()) {
							HTML
									.append("         <td align=center width='15%'><a href=\"\" id='"
											+ empid
											+ "'onclick=\"doAdviceSubmit(this); return false;\"><img src='../images/view.gif' align=center onMouseOver=\"javascript:this.src='../images/view_over.gif'\" onMouseOut=\"javascript:this.src='../images/view.gif'\" width='19' height='19' border='0'/></a></td>");
						} else {
							// added by kevin 9Feb 2011 end
							String dummyStr = encript(empid + "," + year + ","
									+ month + "," + pagenum);
							String link = "PdfView?link=" + dummyStr;
							HTML
									.append("         <td align=center width='15%'><a href=\"\" onclick=\"openReadWindow('"
											+ link
											+ "'); return false;\"><img src='../images/view.gif' align=center onMouseOver=\"javascript:this.src='../images/view_over.gif'\" onMouseOut=\"javascript:this.src='../images/view.gif'\" width='19' height='19' border='0'/></a></td>");
						}
					} else {
						HTML
								.append("         <td align=center width='15%'><a href=\"javascript:detail('"
										+ encript(empid)
										+ "','"
										+ encript(year)
										+ "','"
										+ encript(month)
										+ "',"
										+ pagenum
										+ ")\"><img src='../images/view.gif' align=center onMouseOver=\"javascript:this.src='../images/view_over.gif'\" onMouseOut=\"javascript:this.src='../images/view.gif'\" width='19' height='19' border='0'/></a></td>");
					}
					HTML.append(lnTag);

					if (html_pdf) {
						HTML
								.append("         <td align=center width='15%'><input name=CHECKBOX type=checkbox value='"
										+ empid + "'");
						if (checked.contains(empid)) {
							HTML.append(" checked");
						}
						HTML.append("></td>");
					}
					HTML.append(lnTag);
					HTML.append("     </tr>");
					HTML.append(lnTag);
				}
			}

			// added by kevin start
			HTML
					.append(" <form name='adviceForm' method='post' action='/epayslip/servlet/EPSController'>\r\n");
			HTML
					.append("	<input type='hidden' name='event' value='MPF_ORSO_ADVICE_FORM_INTERFACE'>\r\n");
			HTML.append("	<input type='hidden' name='pid' value=''>\r\n");
			HTML.append("	<input type='hidden' name='year' value='" + year
					+ "'>\r\n");
			HTML.append("	<input type='hidden' name='month' value='" + month
					+ "'>\r\n");
			HTML
					.append("	<input type='hidden' name='grp_id' value='HR_ADMIN'>\r\n");
			HTML.append("	<input type='hidden' name='page' value='" + pagenum
					+ "'>\r\n");
			HTML.append("	<input type='hidden' name='condition' value='"
					+ condition + "'>\r\n");
			HTML.append("	<input type='hidden' name='eready' value='" + eready
					+ "'>\r\n");
			HTML.append("	<input type='hidden' name='value' value='" + value
					+ "'>\r\n");
			HTML.append("	<input type='hidden' name='maxsize' value='"
					+ maxsize + "'>\r\n");
			HTML.append("	<input type='hidden' name='checked' value='"
					+ checked + "'>\r\n");
			HTML.append(" </form>");
			// added by kevin end

			// for pageing arithmetic
			if (pages > 1) {
				HTML
						.append(" <form name='formOwn' method='post' action='/epayslip/servlet/EPSController'>");
				HTML.append(lnTag);
				HTML.append("     <tr bgcolor='#ffffff'>");
				HTML.append(lnTag);
				//HTML.append("         <td colspan=4 height=27 align=right> page:  ");
				HTML.append("         <td colspan=4 height=27 align=right>"+rb.getString("epayslip.employee.page")+"");
				HTML.append(lnTag);

				if (pages <= 11) {
					if (pagenum != 1)
						HTML.append("<a href='javascript:nextPage(\""
								+ (pagenum - 1) + "\")'> < </a>&nbsp;");
					for (int i = 0; i < pages; i++) {
						if (pageid == pagenum)
							HTML.append("[" + pageid + "]&nbsp;");
						else
							HTML.append("<a href='javascript:nextPage(\""
									+ pageid + "\")'>" + pageid + "</a>&nbsp;");
						pageid++;
					}
					if (pagenum != pages)
						HTML.append(" <a href='javascript:nextPage(\""
								+ (pagenum + 1) + "\")'> > </a>");
				} else {
					if (pagenum > 6)
						HTML.append("<a href='javascript:nextPage(\"" + 1
								+ "\")'> << </a>&nbsp;");
					if (pagenum != 1)
						HTML.append("<a href='javascript:nextPage(\""
								+ (pagenum - 1) + "\")'> < </a> ");
					if (pagenum > 6)
						HTML.append(" ... ");

					if (pagenum <= 6) {
						for (int i = 0; i < 11; i++) {
							if (pageid == pagenum)
								HTML.append("[" + pageid + "]&nbsp;");
							else
								HTML.append("<a href='javascript:nextPage(\""
										+ pageid + "\")'>" + pageid
										+ "</a>&nbsp;");
							pageid++;
						}
					} else if (pagenum > 6 && pagenum < pages - 5) {
						pageid = pagenum - 5;
						for (int i = pagenum - 5; i <= (pagenum + 5); i++) {
							if (pageid == pagenum)
								HTML.append("[" + pageid + "]&nbsp;");
							else
								HTML.append("<a href='javascript:nextPage(\""
										+ pageid + "\")'>" + pageid
										+ "</a>&nbsp;");
							pageid++;
						}
					} else {
						pageid = pages - 10;
						for (int i = pages - 10; i <= pages; i++) {
							if (pageid == pagenum)
								HTML.append("[" + pageid + "]&nbsp;");
							else
								HTML.append("<a href='javascript:nextPage(\""
										+ pageid + "\")'>" + pageid
										+ "</a>&nbsp;");
							pageid++;
						}
					}

					if (pages - pagenum >= 6)
						HTML.append("... ");
					if (pagenum != pages)
						HTML.append(" <a href='javascript:nextPage(\""
								+ (pagenum + 1) + "\")'> > </a>");
					if (pages - pagenum >= 6)
						HTML.append("&nbsp;<a href='javascript:nextPage(\""
								+ pages + "\")'> >> </a>");
				}
				HTML.append("     	</td>");
				HTML.append(lnTag);

				HTML
						.append("     	  <td colspan=1 align='right' style='border-left-width:0px;'><font color='#ff0000' face='Vedana, Arial, Helvetica, sans-serif' size='1'>");
				HTML.append(lnTag);
				HTML.append("     	    <input type='button' value='10' style='border:1px solid #000; align='center'; height:20px;width:20px;"
								+ ((maxsize == 10) ? "background-color:#ff8000;"
										: "")
								+ "' onclick='javascript:find1(10);'>");
				HTML.append(lnTag);
				HTML.append("     	    <input type='button' value='15' style='border:1px solid #000; align='center'; height:20px;width:20px;"
								+ ((maxsize == 15) ? "background-color:#ff8000;"
										: "")
								+ "' onclick='javascript:find1(15);'>");
				HTML.append(lnTag);
				HTML.append("     	    <input type='button' value='20' style='border:1px solid #000; align='center'; height:20px;width:20px;"
								+ ((maxsize == 20) ? "background-color:#ff8000;"
										: "")
								+ "' onclick='javascript:find1(20);'>");
				HTML.append(lnTag);
				HTML.append("     	    <input type='button' value='"+rb.getString("epayslip.value1")+"' style='border:1px solid #000;align='center';height:20px;width:20px;"
								+ ((maxsize == 10000) ? "background-color:#ff8000;"
										: "")
								+ "' onclick='javascript:find1(10000);'>");
				HTML.append(lnTag);
				HTML
						.append("			<input type='hidden' name='maxsize' value=''></font>");
				HTML.append(lnTag);
				HTML.append("			<input type='hidden' name='checked' value='"
						+ checked + "'>");
				HTML.append(lnTag);
				HTML.append("     	  </td>");

				HTML.append("     </tr>");
				HTML.append(lnTag);
			} else {
				HTML
						.append(" <form name='formOwn' method='post' action='/epayslip/servlet/EPSController'>");
				HTML.append(lnTag);
				HTML.append("     <tr bgcolor='#ffffff'>");
				HTML
						.append("     	  <td colspan=5 height=27 align='right'><font color='#ff0000' face='Vedana, Arial, Helvetica, sans-serif' size='1'>");
				HTML.append(lnTag);
				HTML
						.append("     	    <input type='button' value='10' style='border:1px solid #000; align='center'; height:20px;width:20px;"
								+ ((maxsize == 10) ? "background-color:#ff8000;"
										: "")
								+ "' onclick='javascript:find1(10);'>");
				HTML.append(lnTag);
				HTML
						.append("     	    <input type='button' value='15' style='border:1px solid #000; align='center'; height:20px;width:20px;"
								+ ((maxsize == 15) ? "background-color:#ff8000;"
										: "")
								+ "' onclick='javascript:find1(15);'>");
				HTML.append(lnTag);
				HTML
						.append("     	    <input type='button' value='20' style='border:1px solid #000; align='center'; height:20px;width:20px;"
								+ ((maxsize == 20) ? "background-color:#ff8000;"
										: "")
								+ "' onclick='javascript:find1(20);'>");
				HTML.append(lnTag);
				HTML
						.append("     	    <input type='button' value='"+rb.getString("epayslip.employee.all")+"' style='border:1px solid #000;align='center'; height:20px;width:20px;"
								+ ((maxsize == 10000) ? "background-color:#ff8000;"
										: "")
								+ "' onclick='javascript:find1(10000);'>");
				HTML.append(lnTag);
				HTML
						.append("			<input type='hidden' name='maxsize' value=''></font>");
				HTML.append(lnTag);
				HTML.append("			<input type='hidden' name='checked' value='"
						+ checked + "'>");
				HTML.append(lnTag);
				HTML.append("     	  </td>");
				HTML.append("     </tr>");
				HTML.append(lnTag);
			}

			HTML
					.append("	<input type='hidden' name='event' value='VIEW_PAYSLIP_LIST'>");
			HTML.append(lnTag);
			HTML.append("	<input type='hidden' name='year' value='" + year
					+ "'>");
			HTML.append(lnTag);
			HTML.append("	<input type='hidden' name='month' value='" + month
					+ "'>");
			HTML.append(lnTag);
			HTML.append("	<input type='hidden' name='condition' value='"
					+ condition + "'>");
			HTML.append(lnTag);
			HTML.append("	<input type='hidden' name='value' value='" + value
					+ "'>");
			HTML.append(lnTag);
			HTML.append("	<input type='hidden' name='page' value='" + pagenum
					+ "'>");
			HTML.append(lnTag);
			HTML.append("	<input type='hidden' name='checked' value='"
					+ checked + "'>");
			HTML.append("	<input type='hidden' name='eready' value='" + eready
					+ "'>");
			HTML.append(lnTag);
			HTML.append("</form>");
			HTML.append(lnTag);

			// for search function
			HTML
					.append("	<form name='formSearch' method='post' action='/epayslip/servlet/EPSController'>");
			HTML.append(lnTag);
			HTML
					.append("	<input type='hidden' name='event' value='VIEW_PAYSLIP_LIST'>");
			HTML.append(lnTag);
			HTML.append("	<input type='hidden' name='year' value='" + year
					+ "'>");
			HTML.append(lnTag);
			HTML.append("	<input type='hidden' name='month' value='" + month
					+ "'>");
			HTML.append(lnTag);

			HTML.append("     <tr bgcolor='#CCCCCC'>");
			HTML.append(lnTag);
			HTML
					.append("         <td colspan=5 height=27 style='border-right-width:0px;'>");
			HTML.append(lnTag);
			HTML.append("			<select name='condition'>");
			if (condition.equalsIgnoreCase("id")) {
				//HTML.append("				<option value='id' selected>Employee ID</option>").append(lnTag); 
				HTML.append("				<option value='id' selected>" + rb.getString("epayslip.employee.id") +"</option>").append(lnTag); 
			} else {
			//	HTML.append("				<option value='id'>Employee Id</option>").append(lnTag);
				HTML.append("				<option value='id'>" + rb.getString("epayslip.employee.id") +"</option>").append(lnTag);
			}
			if (condition.equalsIgnoreCase("name")) {
				//HTML.append("				<option value='name' selected>Employee Name</option>").append(lnTag);
				HTML.append("				<option value='name' selected>" + rb.getString("epayslip.employee.name") +"</option>").append(lnTag);
			} else {
			//	HTML.append("				<option value='name'>Employee Name</option>").append(lnTag);
				HTML.append("				<option value='name'>" + rb.getString("epayslip.employee.name") +"</option>").append(lnTag);
			}

			HTML.append("			</select>");
			HTML.append("			<input type='text' name='value' value='" + value+ "'>");
			HTML.append(lnTag);

			//HTML.append("e-Ready"); 
			HTML.append(""+ rb.getString("epayslip.employee.eReady") +"");
			String chk2 = "";
			String chk1 = "";
			String chk0 = "";
			if (eready.equals("2")) {
				chk2 = "checked='checked'";
			}
			if (eready.equals("1")) {
				chk1 = "checked='checked'";
			}
			if (eready.equals("0")) {
				chk0 = "checked='checked'";
			}
			//HTML.append("<input name='eready' type='radio' value='2' onclick='javascript:find();' "+ chk2 + ">All");
			//HTML.append("<input name='eready' type='radio' value='1' onclick='javascript:find();' "+ chk1 + ">Yes");
			//HTML.append("<input name='eready' type='radio' value='0' onclick='javascript:find();' "+ chk0 + ">No");
			
			HTML.append("<input name='eready' type='radio' value='2' onclick='javascript:find();' "+ chk2 + ">"+ rb.getString("epayslip.employee.all") +"");
			HTML.append("<input name='eready' type='radio' value='1' onclick='javascript:find();' "+ chk1 + ">"+ rb.getString("epayslip.employee.yes") +"");
			HTML.append("<input name='eready' type='radio' value='0' onclick='javascript:find();' "+ chk0 + ">"+ rb.getString("epayslip.employee.no") +"");


			HTML.append("			<input type='button' value='"+rb.getString("epayslip.employee.search")+"' onclick='javascript:find();'>");
			HTML.append(lnTag);
			if (html_pdf) {
				HTML
						.append("&nbsp<input type='button' value='"+rb.getString("epayslip.employee.download")+"' onclick='javascript:download();'>");
				//==========================================================↓ henry 19,April 2012==========================================================
				HTML.append("&nbsp<input type='button' value='"+rb.getString("epayslip.employee.upload")+"' onclick='javascript:upload();'>");
				//==========================================================↑ henry 19,April 2012==========================================================
				HTML.append(lnTag);
			}
			HTML.append("     </td>");
			HTML.append(lnTag);
			HTML.append("     </tr>");
			HTML.append(lnTag);
			HTML.append("	</form>");
			HTML.append(lnTag);
			
			//==========================================================↓ henry 30,May 2012==========================================================
			HTML.append("<tr bgcolor='#CCCCCC'>");
			HTML.append("<td colspan='5' width=100% >");
			HTML.append("<div id='uploaddiv' style='display:none;'>");
			HTML.append("<form id='uploadform' method='post' ENCTYPE='multipart/form-data' action='/epayslip/servlet/EPSController?event=UPLOAD'>").append(lnTag);
			HTML.append("&nbsp&nbsp<input TYPE='FILE' id='fileupload'  NAME='fileUpload'  size='20'  onkeydown='return false' onkeyup='return false'  /> ");
			HTML.append("&nbsp<input type='button' name='uploadsubmit' value='"+rb.getString("epayslip.submit")+"' onClick='doUpload()'>");
			HTML.append("</form>").append(lnTag);
			HTML.append("</div>");
			
			//==========================================================↑ henry 30,May 2012==========================================================
			
			// for logout
			HTML.append("	<form name='logout' method='post' action='/epayslip/servlet/EPSController'>").append(lnTag);
			HTML.append("		<input type='hidden' name='event' value='SSOLOGOUT'>").append(lnTag);
			HTML.append("	</form>").append(lnTag);

			// for back
			HTML.append("	<form name='backToStart' method='post' action='/epayslip/servlet/EPSController'>");
			HTML.append(lnTag);
			HTML.append("		<input type='hidden' name='event' value='VIEW_PAYSLIP_LIST'>");
			HTML.append(lnTag);
			HTML.append("		<input type='hidden' name='year' value='" + year+ "'>");
			HTML.append(lnTag);
			HTML.append("		<input type='hidden' name='month' value='" + month+ "'>");
			HTML.append(lnTag);
			HTML.append("	</form>").append(lnTag);

			/**
			 * for pdf download
			 */
			HTML
					.append("	<form name='pdfdownload' method='post' action='Pdfdownload'>");
			HTML.append(lnTag);
			HTML.append("		<input type='hidden' name='event' value='PDF_DOWNLOAD'>");
			HTML.append(lnTag);
			HTML.append("		<input type='hidden' name='year' value='" + year+ "'>");
			HTML.append(lnTag);
			HTML.append("		<input type='hidden' name='month' value='" + month+ "'>");
			HTML.append(lnTag);
			HTML.append("		<input type='hidden' name='selectedid' value=''>");
			HTML.append(lnTag);
			HTML.append("		<input type='hidden' name='selectedAdviceId' value=''>");
			HTML.append(lnTag);
			HTML.append("		<input type='hidden' name='dtype' value=''>");
			HTML.append(lnTag);
			HTML.append("	</form>").append(lnTag);

			// for employee's detail epayslip
			HTML.append("	<form name='epayslip' method='post' action='/epayslip/servlet/EPSController'>");
			HTML.append(lnTag);
			HTML.append("		<input type='hidden' name='event' value='VIEW_PAYSLIP'>");
			HTML.append(lnTag);
			HTML.append("		<input type='hidden' name='check' value=''>");
			HTML.append(lnTag);
			HTML.append("		<input type='hidden' name='theYear' value=''>");
			HTML.append(lnTag);
			HTML.append("		<input type='hidden' name='theMonth' value=''>");
			HTML.append(lnTag);
			HTML.append("		<input type='hidden' name='page' value=''>");
			HTML.append(lnTag);
			HTML.append("	</form>").append(lnTag);
			HTML.append("</td>");
			HTML.append("</tr>");
			HTML.append("   </table>").append(lnTag);

			HTML.append("	<table  align='center' width='600' border='0' cellspacing='0' cellpadding='0' height='23' background='/epayslip/images/bottbar.gif'> ").append(lnTag);
			HTML.append("		<tr> ").append(lnTag);
			HTML.append("			<td> ").append(lnTag);
			HTML.append("				<table width='585' border='0' cellspacing='0' cellpadding='0' align='center'>").append(lnTag);
			HTML.append("					<tr>").append(lnTag);

			if (!value.equalsIgnoreCase("")) {
				//HTML.append("					<td width='189'><a href='javascript:backToStart();'><b>BACK</b></a></td>").append(lnTag);
				HTML.append("					<td width='189'><a href='javascript:backToStart();'><b>"+ rb.getString("epayslip.employee.BACKonly") +"</b></a></td>").append(lnTag);
			} else {
				//HTML.append("					<td width='189'><a href='EPSController?event=SSOLOGIN'><b>BACK</b></a></td>").append(lnTag);
				HTML.append("					<td width='189'><a href='EPSController?event=SSOLOGIN'><b>"+ rb.getString("epayslip.employee.BACKonly") +"</b></a></td>").append(lnTag);
			}

			HTML.append("						<td> ");
			//HTML.append("							<div align='right'><a href='javascript:closeMe()'><b>LOGOUT</b></a></div>");
			HTML.append("							<div align='right'><a href='javascript:closeMe()'><b>"+ rb.getString("epayslip.logout.button") +"</b></a></div>");
			HTML.append("						</td>");
			HTML.append("					</tr>");
			HTML.append("				</table>");
			HTML.append("			</td>");
			HTML.append("		</tr>");
			HTML.append("	</table>");

			HTML.append("<br>");

			SimpleDateFormat df = new SimpleDateFormat("yyyy");
			String curyear = df.format(new Date());

			HTML
					.append(
							"<table align='center' width='320' border='0' cellspacing='0' cellpadding='0' height='60'>")
					.append(lnTag);
			HTML.append("	<tr> ").append(lnTag);
			HTML
					.append("		<td width='90' align='cente' height='64'><img src='/epayslip/images/epaysmall2.gif' width='82' height='31'></td>");
			HTML
					.append(
							"		<td width='230' align='center' height='64'><font size='1'>&#149; &nbsp; ")
					.append(lnTag);
			HTML.append(
					"			 &copy; " + curyear
							+ " "+rb.getString("epayslip.iadmin.all.rights.reserved")+"</font></td>")
					.append(lnTag);
			HTML.append("	</tr>").append(lnTag);
			HTML.append("</table>").append(lnTag);
			HTML.append(lnTag);
			/**
			 * HTML.append(lnTag);
			 * HTML.append("<jsp:include page=\"menu.jsp\" flush=\"true\"/>");
			 * HTML.append(lnTag);
			 */
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}

		HTML.append("</body>");
		HTML.append(lnTag);
		HTML.append("</html>");
		HTML.append(lnTag);

		response.setContentType("text/html;charset=utf-8");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Cache-Control", "no-cache");
		response.setDateHeader("Expires", 0);


		out.print(HTML);
		// end reading of the epayslip list of all the employee

		/*
		 * request.setAttribute("EPAYSLIP_YEAR",year);
		 * request.setAttribute("EPAYSLIP_MONTH",request.getParameter("month"));
		 * request.setAttribute("logo_img", comId+".gif");
		 */
		request.setAttribute("FORWARD_URL", "VIEW_NOFORWARD");

	}

	public void forward(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		String key = (String) request.getAttribute("FORWARD_URL");
		request.removeAttribute("FORWARD_URL");
		if (key == null)
			key = "";

		if (!key.equals("VIEW_NOFORWARD")) {
			RequestDispatcher rd = request.getRequestDispatcher(bundle
					.getString(key));
			rd.forward(request, response);
		}

	}

	private String encript(final String year) {
		String ret = "";
		String str = year;
		BASE64Encoder encode = new BASE64Encoder();
		try {
			ret = encode.encode(str.getBytes("utf-8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return ret;
	}
	
	private String getDob(String p_id,HttpServletRequest request){
		SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
		String dob = "";
		Connection conn = null;
    	ConnectionPool cp = new ConnectionPool();
    	Statement stm = null;
    	// Get login user's name
    	HttpSession session = request.getSession();
    	
    	String epayslip = (String)session.getAttribute(Constant.POOL_NAME);
    	try {
    		//initialize the db_connection of epayroll schema of the right client
	        //conn = initConn(request);
    		
    		conn = cp.getConnection(epayslip);
    		stm = conn.createStatement();
			ResultSet rs = stm.executeQuery("select dob from pay_emp where p_id='"+p_id+"'");
			while(rs.next()){
				if(rs.getDate("dob")!=null){
					dob = sdf.format(rs.getDate("dob"));
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
            try {
            	if(stm != null) {
            		stm.close();
                    cp.closeConnection(conn);
            	}
        	} catch(SQLException e1) {
        		e1.printStackTrace();
        	};
        }
		return dob;
	}
public void dialogPage(StringBuffer HTML)
{
	HTML.append("<table>");
	HTML.append("<tr height='20px'>");
	HTML.append("<td colspan='2'>&nbsp;</td>");
	HTML.append("</tr>");
	HTML.append("<tr>");
	HTML.append("<td colspan='2'>");
	HTML.append("" + rb.getString("epayslip.select.option") +"");
	HTML.append("</td>");
  	HTML.append("</tr>");
  	HTML.append("<tr height='20px'>");
  	HTML.append("<td colspan='2'>&nbsp;</td>");
  	HTML.append("</tr>");
  	HTML.append("<tr>");
  	HTML.append("<td align='left'>");			
  	HTML.append("<input type='radio' name=for value='one'>" + rb.getString("epayslip.select.one.PDF") +"&nbsp;&nbsp;&nbsp;&nbsp");
  	HTML.append("</td>");
  	HTML.append("</tr>");
  	HTML.append("<tr>");
  	HTML.append("<td align='left'>"); 			
  	HTML.append("<input type='radio' name=for value='all'>" + rb.getString("epayslip.select.endividual.pdf") +"");
  	HTML.append("</td>");
  	HTML.append("</tr>");
  	HTML.append("<tr height='20px'>");
  	HTML.append("<td colspan='2'>&nbsp;</td>");
  	HTML.append("</tr>");
  	HTML.append("<tr>");
  	HTML.append("<td align='center'>"); 			
  	HTML.append("<input type='button' name=fordown value='"+ rb.getString("epayslip.download.pdf2") +"' onclick='callBack2();'>");
  	HTML.append("</td>");
  	HTML.append("</tr>");
  	HTML.append("</table>");
}

}



