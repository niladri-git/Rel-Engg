package epayslip.system;

import edu.yale.its.tp.cas.client.filter.CASFilter;
import epayslip.db.*;
import epayslip.system.event.*;
import epayslip.utility.ConfigUtil;
import catalog.sso.GlobalSession;

import java.io.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.ConfigurationFactory;

/**
 * System Controller controls the whole application
 */
public class EPaySlipController extends HttpServlet {

    protected HashMap events = new HashMap();  //unsynchronized, to event mapping
 
    private static String filePath;
    
    //private DbConnectionBroker dbBroker_MASTER; 
    //private DbConnectionBroker dbBroker_SLAVE; 
    private static User usr;
    private static EpayslipUserList epayslipUserList;
    private static int menu_start_year;
    private static String doc_root;
    private static String frontPage;
    
    public void init () throws ServletException {

        System.out.println("epayslip init");
        //Get the file path
        filePath = this.getServletContext().getRealPath("/WEB-INF/classes/");
        
        usr = new User();
        
        
        // get the event values and save them into events
        ResourceBundle bundle = ResourceBundle.getBundle ("Events");
        ResourceBundle config = ResourceBundle.getBundle("SystemConfig");
        //ResourceBundle highAvail = ResourceBundle.getBundle("HighAvail");
        //InetAddress inetAddr = null;
        
        Enumeration e = bundle.getKeys();

        while (e.hasMoreElements()) {
	          String key = (String) e.nextElement();
	          String value = bundle.getString(key);
	
	          try {
	        	  //inetAddr = InetAddress.getLocalHost();
	            
	        	  EventHandler event = (EventHandler) Class.forName(value).newInstance();
	        	  events.put (key, event);
	
	        	  /*} catch (UnknownHostException e1) {
	                	System.out.println(e1.getMessage());*/
		       } catch (Exception exp) {
		                System.out.println("No handler found!\n" + exp.toString());
		       } finally {
		
		       }
        }

        //String dbDriver,dbUrl,dbUser,dbPassword,dbRemotePassword,dbMin,dbMax,dbLog,dbConTime;
        //String hostName = inetAddr.getHostName();
        
        /*dbDriver = config.getString("DB_DRIVER_NAME");
        dbUrl = config.getString("DB_URL");
        dbUser = config.getString("DB_USER");
        dbPassword = config.getString("DB_PASSWORD");
        dbRemotePassword = config.getString("DB_REMOTEPASSWORD");
        dbMin = config.getString("DB_MIN_CONN");
        dbMax = config.getString("DB_MAX_CONN");
        dbLog = config.getString("DB_LOG_PATH");
        dbConTime = config.getString("DB_MAX_CONN_TIME");*/
        menu_start_year = Integer.parseInt(config.getString("MENU_START_YEAR"));
        
        //edited by Julius.Liu on 14 DEC 2006 for different os
        String osName = java.lang.System.getProperty("os.name");
        if (osName.startsWith("Win")) {
        	doc_root = config.getString("DOC_ROOT_NT");
        }else{
        	doc_root = config.getString("DOC_ROOT");
        }
        frontPage = config.getString("FIRSTPAGE_LINK");
        
        /*try{
            // Slave host connects to master DB
            if (hostName.equals(highAvail.getString("slave_DB"))) {
                dbPassword = dbRemotePassword;
            }

            dbUrl = dbUrl.replaceAll("localhost", highAvail.getString("master_DB"));

            dbBroker_MASTER = new DbConnectionBroker(dbDriver,
                                         dbUrl,
                                         dbUser,dbPassword,Integer.parseInt(dbMin),Integer.parseInt(dbMax),
                                         dbLog,Double.parseDouble(dbConTime));                                         

        } catch (IOException e5)  { 
            System.out.println("Cannot establish connection for master DB.");
            dbBroker_MASTER = null;
        }*/

        epayslipUserList = new EpayslipUserList();
        
        /*if (highAvail.getString("cluster").equalsIgnoreCase("true")) {
            try {
            	// Master host connects to slave DB
                if (hostName.equals(highAvail.getString("master_DB"))) {
                    dbPassword = dbRemotePassword;
                }
                dbUrl = dbUrl.replaceAll(highAvail.getString("master_DB"), highAvail.getString("slave_DB"));
                dbBroker_SLAVE = new DbConnectionBroker(dbDriver,
                                         dbUrl,
                                         dbUser,dbPassword,Integer.parseInt(dbMin),Integer.parseInt(dbMax),
                                         dbLog,Double.parseDouble(dbConTime));
            } catch (IOException e5)  { 
                System.out.println("Cannot establish connection for slave DB.");
                dbBroker_SLAVE = null;
            }

            DBUtility dbUtil = new DBUtility();
            
            if ((dbBroker_MASTER != null) && (dbBroker_SLAVE != null)) {
                usr = new User(dbBroker_MASTER, dbBroker_SLAVE);
                
            } else if ((dbBroker_MASTER != null) && (dbBroker_SLAVE == null)) {
                usr = new User(dbBroker_MASTER, dbBroker_SLAVE);
                dbUtil.sendEmail(highAvail.getString("email"), highAvail.getString("slave_DB"), "epayslip slave DB");
                
            } else if ((dbBroker_SLAVE != null) && (dbBroker_MASTER == null)) {
                usr = new User(dbBroker_MASTER, dbBroker_SLAVE);
                dbUtil.sendEmail(highAvail.getString("email"), highAvail.getString("master_DB"), "epayslip master DB");
                
            } else {
                dbUtil.sendEmail(highAvail.getString("email"), 
                highAvail.getString("master_DB")+highAvail.getString("slave_DB"), "epayslip Both DB");
            }
        } else { // non-cluster environment
            usr = new User(dbBroker_MASTER);
        }*/
        
    }//end init

    public void destroy() 
    {

    }
  
    public static User getUserManager()
    {
        return usr;    
    }
    
    public static EpayslipUserList getEpayslipUserList()
    {
        return epayslipUserList;    
    }
    
    public static int getMenuStartYear()
    {
        return menu_start_year;    
    }
    
    public static String getDocRoot()
    {
        return doc_root;    
    }
        
    public static String getFirstPageUrl()
    {
        return frontPage;    
    }
    
    public void doGet (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        doPost (request, response);
    }

    public void doPost (HttpServletRequest request, 
                      HttpServletResponse response) throws ServletException, IOException 
    {        
        EventHandler handler;
        //validate the event
        String given_name="";
    	String surname="";
    	String empId, logo_link;
        String event = validateEvent (request);
System.out.println("======================="+event+"======================");
        handler = getEventHandler (event); //Get normal handler

        if(event.startsWith("VIEW")||event.startsWith("UPDATEDETAILS")||event.startsWith("E-")) //if the prefix start with this, check session
        {
            HttpSession session = request.getSession();
            String login_name = (String)session.getAttribute(CASFilter.CAS_FILTER_USER);
            GlobalSession gsession = new GlobalSession();
            empId = (String) session.getAttribute("LOGIN_PID");
        	if( empId == null ){
        		empId = (String)gsession.getAttribute(login_name, "P_ID");
        		surname = (String)gsession.getAttribute(login_name, "SURNAME");
        		given_name = (String)gsession.getAttribute(login_name, "GIVEN_NAME");
        		logo_link=(String)gsession.getAttribute(login_name,"LOGO_LINK");
    	    	session.setAttribute("LOGIN_PID",empId);
    	    	session.setAttribute("LOGIN_SURNAME",surname);
        		session.setAttribute("LOGIN_GIVENAME",given_name);
        		session.setAttribute("LOGO_LINK",logo_link);
        	}
            if(empId==null) //Session expired
            {
                handler = getEventHandler (Constants.SESSION_EXPIRED);
            }
            String groupId = (String) session.getAttribute(User.LOGIN_GROUPID)==null?"":(String) session.getAttribute(User.LOGIN_GROUPID);
            if(event.equals("VIEW_PAYSLIP") && !groupId.equals("HR_ADMIN") && groupId!=null){
	            String year = request.getParameter("year");
	            String month = request.getParameter("month");
	            System.out.printf("(debug info) Selected Year %s, month %s",year,month);
	            System.out.println();
	            
	            boolean html_pdf = ConfigUtil.getPdfFlag(year, month, request);
	            
	            if(html_pdf)
	            	request.getRequestDispatcher("/servlet/PdfView")
						.forward(request, response);
            }
        }
        
        try {
        	System.out.println("=======================into handler.process:"+handler.getClass().getName()+"======================");
            //process the request
        	
            handler.process (getServletContext(), request, response);

        } catch (DBAccessException e) {
            request.setAttribute("error", e );
            handler = getEventHandler(Constants.ERROR_EVENT);          
        } catch (Exception e) {
        	e.printStackTrace();
            request.setAttribute("error", e );
            handler = getEventHandler(Constants.ERROR_EVENT);          
        }

        if (!event.equals("SSOLOGOUT") && !event.equals("SSOMENU")){
        	//foward to the result.
        	handler.forward (request, response);
        }
    }

    //validate the event to make sure is inside the config file
    protected String validateEvent (HttpServletRequest request) {
        String e = request.getParameter(Constants.EVENT);
        if (e == null || !events.containsKey(e)) {
          e = Constants.UNKNOWN_EVENT;
        }

        return e;
    }

    protected EventHandler getEventHandler (String e) {
        EventHandler h;
        try {
          h = (EventHandler) events.get(e);
        } catch (Exception exc) {
          h = (EventHandler) events.get(Constants.UNKNOWN_EVENT);
        }

        return h;
    }


    public static String getFilePath()
    {
        return filePath;
    }
    
}
