package epayslip.db;

import epayslip.system.EPaySlipController;
import epayslip.system.event.*;
import epayslip.db.init.ConnectionPool;
import epayslip.mailer.*;

import catalog.Catalog;
import catalog.constant.Constant;
import com.javaexchange.dbConnectionBroker.*;
import java.sql.*;
import java.util.ResourceBundle;
import java.util.MissingResourceException;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Vector;
import java.util.StringTokenizer;
import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class User
{
    public static final String LOGIN_ID = "LOGIN_ID";
    public static final String LOGIN_GROUPID = "LOGIN_GROUPID";
    public static final String LOGIN_COMID = "LOGIN_COMID";
    public static final String LOGIN_PID = "LOGIN_PID";
    public static final String LOGIN_PDAY = "LOGIN_PDAY";
    public static final String LOGIN_SURNAME = "LOGIN_SURNAME";
    public static final String LOGIN_GIVENNAME = "LOGIN_GIVENAME";
    public static final String LOGIN_USERID = "LOGIN_USERID";
    public static final String LOGIN_DOB = "LOGIN_DOB";

    //===============================================
    //Added on 17 March 2004 for HSBCSG
    //Change the expiration interval of password change to 90 days. 
    // 3 is used here cause of 3 months X 30days. Therefore 90 days.
    //===============================================
    public static final int HSBC_PASSWORD_PERIOD = 3;

    //Added on 6th August 2003 for periodical email update
    public static final String LOGIN_EMAIL = "LOGIN_EMAIL";
    public static final String LOGIN_NEXTEMAILUPDATEPROMPTDATE = "LOGIN_NEXTEMAILUPDATEPROMPTDATE";
    public static final int EMAIL_UPDATE_PERIOD = 6;

    //Added on 29th April 2003 for super & root user access
    public static final String LOGIN_EMPSTATUS = "LOGIN_EMPSTATUS";
    public static final int ROOT_USER = 9;
    public static final int SUPER_USER = 8;

    //Added on 8th October 2003 for group user access
    public static final String LOGIN_LOCATION = "LOGIN_LOCATION";
    public static final int GROUP_USER = 7;

    //Added on 26th November 2003 for paysun add secret answer
    public static final String LOGIN_ANSWER = "LOGIN_ANSWER";

    // for e-Memo
    public static final int MAXCOLUMN = 20;

    // for clustering
    public static final int MASTER_DB = 0;
    public static final int SLAVE_DB = 1;

    private static final String SQL_ENCODE = "encode(?, 'a')";
    private static final String SQL_DECODE = "decode(Password, 'a')";

    private static final String ENCRYPT_KEY = "epayslip";

    private DbConnectionBroker dbMgr[];
    private int CURRENT_DB;

    private String DbName;

    private DBUtility dbUtil;
    public static final String LOCAL = "LOCAL"; //Task ID: 5186 setting language data from session 

    //non-cluster environment
    public User(DbConnectionBroker dbBrk_MASTER)
    {
        ResourceBundle config = null, highAvail = null;

    	dbUtil = new DBUtility();
        dbMgr = new DbConnectionBroker[1];
        dbMgr[MASTER_DB] = dbBrk_MASTER;

        try {
            config = ResourceBundle.getBundle("SystemConfig");
            highAvail = ResourceBundle.getBundle("HighAvail");

        } catch (MissingResourceException e) {
            System.out.println("Missing resource file: " + e.getMessage());
        }

        CURRENT_DB = MASTER_DB;
        String dbUrl = config.getString("DB_URL");
        DbName = dbUrl.substring(dbUrl.lastIndexOf('/')+1, dbUrl.length()) + highAvail.getString("updateDB_delimiter");
    }

    public User(DbConnectionBroker dbBrk_MASTER, DbConnectionBroker dbBrk_SLAVE)
    {
        ResourceBundle config = null, highAvail = null;

    	dbUtil = new DBUtility();
        dbMgr = new DbConnectionBroker[2];
        dbMgr[MASTER_DB] = dbBrk_MASTER;
        dbMgr[SLAVE_DB] = dbBrk_SLAVE;

        try {
            config = ResourceBundle.getBundle("SystemConfig");
            highAvail = ResourceBundle.getBundle("HighAvail");

        } catch (MissingResourceException e1) {
            System.out.println("Missing resource file: " + e1.getMessage());
        }

        CURRENT_DB = (dbBrk_MASTER != null) ? MASTER_DB : SLAVE_DB;
        String dbUrl = config.getString("DB_URL");
        DbName = dbUrl.substring(dbUrl.lastIndexOf('/')+1, dbUrl.length()) + highAvail.getString("updateDB_delimiter");
    }
    
    public User(){
    	
    }
//======================================================================
    //							changed to take out surname in epayslip login checked
    //========================================================================
    public void setRegisteredd(String id,Date dob)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);
        String sql = "";

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("UPDATE user SET existing_user='Y' WHERE p_id=? AND dob=?");

            pstmt.setString(1,id);
            pstmt.setDate(2,dob);

            pstmt.executeUpdate();

            sql = "update user set existing_user = 'Y' where p_id = '" + id +"' and dob = '" + dob + "'";
            dbUtil.sqlToLogFile(dbUtil.getCurrentDbHostName(currentDB) + DbName + sql);

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }

    }
     public boolean validUserr(String id,Date dob)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        boolean result=false;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("SELECT * FROM user WHERE p_id=? AND dob=?");

            pstmt.setString(1,id);
            pstmt.setDate(2,dob);

            ResultSet rs = pstmt.executeQuery();

            if(rs.next()) { //user valid
                result = true;
            }else //invalid user
            {
                result = false;
            }

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
        return result;
    }

    public boolean newUserr(String id,Date dob)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        boolean result=false;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("SELECT * FROM user WHERE p_id=? AND dob=? AND existing_user='Y'");

            pstmt.setString(1,id);
           pstmt.setDate(2,dob);

            ResultSet rs = pstmt.executeQuery();

            if(rs.next()) { //user with exising 'y' status
                result = false;
            }else //is a new user
            {
                result = true;
            }

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
        return result;
    }
    public void setUseridPasswordd(String id,Date dob,String userid,String password,String email,Date nextEmailUpdatePromptDate)
    throws DuplicateIdException, DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);
        String sql = "";

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("UPDATE user SET userid=?,password=?,email=?,nextemailupdatepromptdate=? WHERE p_id=? AND dob=?");

            Encryption encrypt = new Encryption();
            String enpwd = encrypt.getLock(password);

            pstmt.setString(1,userid);
            pstmt.setString(2,enpwd);
            pstmt.setString(3,email);
            pstmt.setDate(4,nextEmailUpdatePromptDate);
            pstmt.setString(5,id);
           pstmt.setDate(6,dob);

            pstmt.executeUpdate();

            sql = "update user set userid = '" + userid + "', password = '" + enpwd + "', email = '" + email +
                  "', nextemailupdatepromptdate = '" + nextEmailUpdatePromptDate + "' where p_id = '" + id + "' and dob = '" + dob + "'";
            dbUtil.sqlToLogFile(dbUtil.getCurrentDbHostName(currentDB) + DbName + sql);

        } catch (SQLException e1) { //error number is 1062
            if (e1.getErrorCode()==1062) {
                throw new DuplicateIdException();
            } else {
                e1.printStackTrace();
                throw new DBAccessException();
            }
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }

    }

 public boolean correctPasswordd(String id,Date dob,String password)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        boolean result=false;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("SELECT password FROM user WHERE p_id=? AND dob=?");

            pstmt.setString(1,id);
            pstmt.setDate(2,dob);

            ResultSet rs = pstmt.executeQuery();

            if(rs.next()) { //password correct
                Encryption encrypt = new Encryption();
                String rpwd = rs.getString("password");
                rpwd = encrypt.getUnlock(rpwd);
               // System.out.println("testing "+rpwd);
                if(password.equals(rpwd))
                {
                    result = true;
                }
            }
            rs.close();

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
        return result;
    }

    public String getGroupIdd(String id,Date dob)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        String result="";
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("SELECT group_id FROM user WHERE p_id=? AND dob=?");

            pstmt.setString(1,id);
            pstmt.setDate(2,dob);

            ResultSet rs = pstmt.executeQuery();

            if(rs.next()) { //user valid
                result = rs.getString("group_id");
                if(result==null){result="";}
            }else //invalid user
            {
                result = "";
            }
            rs.close();

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
        return result;
    }

    public void setQuestionAnswerr(String id,Date dob,int q,String answer)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);
        String sql = "";

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("UPDATE user SET question=?,answer=? WHERE p_id=? AND dob=?");

            pstmt.setInt(1,q);
            pstmt.setString(2,answer);
            pstmt.setString(3,id);
            pstmt.setDate(4,dob);

            pstmt.executeUpdate();

            sql = "update user set question = " + q + ", answer = '" + answer + "' where p_id = '" + id +
                  "' and dob = '" + dob + "'";
            dbUtil.sqlToLogFile(dbUtil.getCurrentDbHostName(currentDB) + DbName + sql);

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }

    }
//==========================================================================
//==========================================================================
//==========================================================================
    


public boolean validUser(String id,String surname,Date dob)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        boolean result=false;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("SELECT * FROM user WHERE p_id=? AND surname=? AND dob=?");

            pstmt.setString(1,id);
            pstmt.setString(2,surname);
            pstmt.setDate(3,dob);

            ResultSet rs = pstmt.executeQuery();

            if(rs.next()) { //user valid
                result = true;
            }else //invalid user
            {
                result = false;
            }
            rs.close();

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
        return result;
    }

    public boolean newUser(String id,String surname,Date dob)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        boolean result=false;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("SELECT * FROM user WHERE p_id=? AND surname=? AND dob=? AND existing_user='Y'");

            pstmt.setString(1,id);
            pstmt.setString(2,surname);
            pstmt.setDate(3,dob);

            ResultSet rs = pstmt.executeQuery();

            if(rs.next()) { //user with exising 'y' status
                result = false;
            }else //is a new user
            {
                result = true;
            }
            rs.close();

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
        return result;
    }

    public boolean correctPassword(String id,String surname,Date dob,String password)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        boolean result=false;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("SELECT password FROM user WHERE p_id=? AND surname=? AND dob=?");

            pstmt.setString(1,id);
            pstmt.setString(2,surname);
            pstmt.setDate(3,dob);

            ResultSet rs = pstmt.executeQuery();

            if(rs.next()) { //password correct
                Encryption encrypt = new Encryption();
                String rpwd = rs.getString("password");
                rpwd = encrypt.getUnlock(rpwd);
               // System.out.println("testing "+rpwd);
                if(password.equals(rpwd))
                {
                    result = true;
                }
            }
            rs.close();

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
        return result;
    }

    public boolean correctPassword(String userid,String password)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        ResultSet rs=null;
        boolean result=false;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("SELECT password FROM user WHERE userid=?");

            pstmt.setString(1,userid);

            rs = pstmt.executeQuery();

            if(rs.next()) { //password correct
                Encryption encrypt = new Encryption();
                String rpwd = rs.getString("password");
                rpwd = encrypt.getUnlock(rpwd);
	//System.out.println("testing "+rpwd);
                if(password.equals(rpwd))
                {
                    result = true;
                }
            }else //incorrect
            {
                result = false;
            }
            rs.close();

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
        return result;
    }

    //Added on 29th April 2003 for root & super user access
    public Vector getAllUserList(String groupID, Vector companyList)
    throws DBAccessException
    {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Vector allUserList = new Vector();
        LinkedList groupUserList;
        String[] item;
        String groupid = "";
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();
            //edited by Julius.Liu for eHR on 14 DEC 2006
//            String sql = "select p_id, given_name, surname from user where group_id=? order by p_id";
            String sql = "select employee_id as p_id,given_name,surname from users a,users_epayslip b where a.employee_id=b.p_id and group_id=? order by p_id";
            pstmt = conn.prepareStatement(sql);
            for (int i=0; i<companyList.size(); i++) {
            	groupid = (String)companyList.get(i);
                pstmt.setString(1, groupid);
                rs = pstmt.executeQuery();
                groupUserList = new LinkedList();
                while (rs.next()) {
                    item = new String[3];
                    item[0] = rs.getString("p_id");
                    item[1] = rs.getString("given_name");
                    item[2] = rs.getString("surname");

                    groupUserList.add(item);
                }
                allUserList.add(groupUserList);
            }
            rs.close();
        }
        
        catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	}
    	finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }

        return allUserList;
    }
    
    //Added on 29th April 2003 for root & super user access
    public Vector getAllEpayslipEmployee(String company, String year, String month, 
    									String condition, String value) throws DBAccessException
    {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        //Vector allUserList = new Vector();
        Vector groupUserList;
        String[] item;
        String condi = "a.employee_id";
        if (condition.equalsIgnoreCase("id")) {

        } else if (condition.equalsIgnoreCase("sur")) {
        	condi = "a.surname";
        } else {
        	condi = "a.given_name";
        }
        
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();
            // get the employees of the company that have epayslip in the time
            String sql = "select a.employee_id p_id, a.surname surname, a.given_name given_name " + 
            			" from (select p_id from users_epayslip where comp_id=?) x, users a, " +
            			" (select client_id from client where client_name=? ) y " +
            			" where a.employee_id=x.p_id and a.client_id=y.client_id " +
            			" and (a.lock_status=0 or a.lock_status is null) ";
            if (!value.equals("")) {
            	sql = sql + " and " + condi + " like '%" + value + "%' ";
            }
            sql = sql + " order by length(a.employee_id),a.employee_id, a.surname, a.given_name";
            pstmt = conn.prepareStatement(sql);
            
            pstmt.setString(1, company);
            pstmt.setString(2, company);
            rs = pstmt.executeQuery();
            groupUserList = new Vector();
            
            while (rs.next()) {
            	
                item = new String[3];
                item[0] = rs.getString("p_id");
                item[1] = rs.getString("given_name");
                item[2] = rs.getString("surname");

                groupUserList.add(item);
            }
            rs.close();
            //allUserList.add(groupUserList);
        }
        catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	}
    	finally {
            try{
            	if(pstmt != null) {
            		pstmt.close();
            	}
        	} catch(SQLException e1)
        	{
        		
        	};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }

        return groupUserList;
    }

    //Added on 29th April 2003 for super & root user access
    //Modified on 8th October for group user access
    public Vector getCompanyList(String groupID, HttpServletRequest request)
    throws DBAccessException
    {
        Connection conn=null;
        Statement stmt=null;
        Vector comList = new Vector();

        if (groupID != null) {
            if (groupID.indexOf(";") > -1) {
                StringTokenizer st = new StringTokenizer(groupID, ";");
                while (st.hasMoreTokens()) {
                    comList.add(st.nextToken());
                }
            } else {
                comList.add(groupID);
            }

            return comList;
        }
        ConnectionPool cp = new ConnectionPool();
        try {
            // Get a DB connection
        	EpayslipUserList epayslipUserList = EPaySlipController.getEpayslipUserList();
        	
    		conn = cp.getConnection((String) request.getSession().getAttribute(Constant.POOL_NAME));
        	//conn = epayslipUserList.initConn(request);
            //edited by Julius.Liu for eHR on 14 DEC 2006
            //String sql = "select distinct group_id from user group by group_id";
            String sql = "select distinct group_id from users_epayslip group by group_id";
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                comList.add(rs.getString("group_id"));
            }
            rs.close();
        }
        catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	}
    	finally {
            try{if(stmt != null) {stmt.close();}} catch(SQLException e1){};

            try {
            	cp.closeConnection(conn);
            } catch (Exception e) {
            	
            }
        }

        return comList;
    }

    public String getGroupId(String id,String surname,Date dob)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        String result="";
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("SELECT group_id FROM user WHERE p_id=? AND surname=? AND dob=?");

            pstmt.setString(1,id);
            pstmt.setString(2,surname);
            pstmt.setDate(3,dob);

            ResultSet rs = pstmt.executeQuery();

            if(rs.next()) { //user valid
                result = rs.getString("group_id");
                if(result==null){result="";}
            }else //invalid user
            {
                result = "";
            }
            rs.close();

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
        return result;
    }

    public void setQuestionAnswer(String id,String surname,Date dob,int q,String answer)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);
        String sql = "";

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("UPDATE user SET question=?,answer=? WHERE p_id=? AND surname=? AND dob=?");

            pstmt.setInt(1,q);
            pstmt.setString(2,answer);
            pstmt.setString(3,id);
            pstmt.setString(4,surname);
            pstmt.setDate(5,dob);

            pstmt.executeUpdate();

            sql = "update user set question = " + q + ", answer = '" + answer + "' where p_id = '" + id +
                  "' and surname = '" + surname + "' and dob = '" + dob + "'";
            dbUtil.sqlToLogFile(dbUtil.getCurrentDbHostName(currentDB) + DbName + sql);

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }

    }

    //Added emailchangedate on 6th August 2003 for periodical email update
    public void setUseridPassword(String id,String surname,Date dob,String userid,String password,String email,Date nextEmailUpdatePromptDate)
    throws DuplicateIdException, DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);
        String sql = "";

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("UPDATE user SET userid=?,password=?,email=?,nextemailupdatepromptdate=? WHERE p_id=? AND surname=? AND dob=?");

            Encryption encrypt = new Encryption();
            String enpwd = encrypt.getLock(password);

            pstmt.setString(1,userid);
            pstmt.setString(2,enpwd);
            pstmt.setString(3,email);
            pstmt.setDate(4,nextEmailUpdatePromptDate);
            pstmt.setString(5,id);
            pstmt.setString(6,surname);
            pstmt.setDate(7,dob);

            pstmt.executeUpdate();

            sql = "update user set userid = '" + userid + "', password = '" + enpwd + "', email = '" + email +
                  "', nextemailupdatepromptdate = '" + nextEmailUpdatePromptDate + "' where p_id = '" + id +
                  "' and surname = '" + surname + "' and dob = '" + dob + "'";
            dbUtil.sqlToLogFile(dbUtil.getCurrentDbHostName(currentDB) + DbName + sql);

        } catch (SQLException e1) { //error number is 1062
            if (e1.getErrorCode()==1062) {
                throw new DuplicateIdException();
            } else {
                e1.printStackTrace();
                throw new DBAccessException();
            }
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }

    }

    public void setPassword(String userid, String newpassword)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);
        String sql = "";

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("UPDATE user SET password=? WHERE userid=?");

            Encryption encrypt = new Encryption();
            String enpwd = encrypt.getLock(newpassword);

            pstmt.setString(1,enpwd);
            pstmt.setString(2,userid);

            pstmt.executeUpdate();

            sql = "update user set password = '" + enpwd + "' where userid = '" + userid + "'";
            dbUtil.sqlToLogFile(dbUtil.getCurrentDbHostName(currentDB) + DbName + sql);

        } catch (SQLException e1) { //error number is 1062
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
	}

    public void setRegistered(String id,String surname,Date dob)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);
        String sql = "";

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("UPDATE user SET existing_user='Y' WHERE p_id=? AND surname=? AND dob=?");

            pstmt.setString(1,id);
            pstmt.setString(2,surname);
            pstmt.setDate(3,dob);

            pstmt.executeUpdate();

            sql = "update user set existing_user = 'Y' where p_id = '" + id + "' and surname = '" + surname +
                  "' and dob = '" + dob + "'";
            dbUtil.sqlToLogFile(dbUtil.getCurrentDbHostName(currentDB) + DbName + sql);

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }

    }

    public int getQuestionNo(String id,Date dob)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        int result=-1;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("SELECT question FROM user WHERE p_id=? AND dob=?");

            pstmt.setString(1,id);
            //pstmt.setString(2,surname);
            pstmt.setDate(2,dob);

            ResultSet rs = pstmt.executeQuery();

            if(rs.next()) { //got question number
                result = rs.getInt("question");
            }
            rs.close();

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
        return result;
    }

    public int getQuestionNo(String userid)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        int result=-1;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("SELECT question FROM user WHERE userid=?");

            pstmt.setString(1,userid);

            ResultSet rs = pstmt.executeQuery();

            if(rs.next()) { //got question number
                result = rs.getInt("question");
            }
            rs.close();

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
        return result;
    }

    public boolean correctAnswer(String id,Date dob,String answer)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        boolean result=false;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("SELECT * FROM user WHERE p_id=? AND dob=? AND answer=?");

            pstmt.setString(1,id);
            //pstmt.setString(2,surname);
            pstmt.setDate(2,dob);
            pstmt.setString(3,answer);

            ResultSet rs = pstmt.executeQuery();

            if(rs.next()) { //answer correct
                result = true;
            }
            rs.close();

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
        return result;
    }

    public boolean correctAnswer(String userid,String answer)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        boolean result=false;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("SELECT * FROM user WHERE userid=? AND answer=?");

            pstmt.setString(1,userid);
            pstmt.setString(2,answer);

            ResultSet rs = pstmt.executeQuery();

            if(rs.next()) { //answer correct
                result = true;
            }
            rs.close();

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
        return result;
    }

    public String getEmail(String id,Date dob)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        String result="";
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("SELECT email FROM user WHERE p_id=? AND dob=?");

            pstmt.setString(1,id);
           // pstmt.setString(2,surname);
            pstmt.setDate(2,dob);

            ResultSet rs = pstmt.executeQuery();

            if(rs.next()) { //got question number
                result = rs.getString("email");
                if(result==null)
                { result=""; }
            }
            rs.close();

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
        return result;
    }

    public String getEmail(String userid)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        String result="";
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("SELECT email FROM user WHERE userid=?");

            pstmt.setString(1,userid);

            ResultSet rs = pstmt.executeQuery();

            if(rs.next()) { //got question number
                result = rs.getString("email");
                if(result==null)
                { result=""; }
            }
            rs.close();

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
        return result;
    }

    public void setEmail(String id,Date dob,String email)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);
        String sql = "";

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("UPDATE user SET email=? WHERE p_id=? AND dob=?");

            pstmt.setString(1,email);
            pstmt.setString(2,id);
           // pstmt.setString(3,surname);
            pstmt.setDate(3,dob);

            pstmt.executeUpdate();

            sql = "update user set email = '" + email + "' where p_id = '" + id + "' and dob = '" + dob + "'";
            
		dbUtil.sqlToLogFile(dbUtil.getCurrentDbHostName(currentDB) + DbName + sql);

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }

    }

    public void setEmail(String userid,String email)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);
        String sql = "";

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("UPDATE user SET email=? WHERE userid=?");

            pstmt.setString(1,email);
            pstmt.setString(2,userid);

            pstmt.executeUpdate();

            sql = "update user set email = '" + email + "' where userid = '" + userid + "'";
            dbUtil.sqlToLogFile(dbUtil.getCurrentDbHostName(currentDB) + DbName + sql);

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
    }

    public void setNextEmailUpdatePromptDate(String userid, Date nextEmailUpdatePromptDate)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);
        String sql = "";

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("UPDATE user SET nextemailupdatepromptdate=? WHERE userid=?");

            pstmt.setDate(1,nextEmailUpdatePromptDate);
            pstmt.setString(2,userid);

            pstmt.executeUpdate();

            sql = "update user set nextemailupdatepromptdate = '" + nextEmailUpdatePromptDate +
                  "' where userid = '" + userid + "'";
            dbUtil.sqlToLogFile(dbUtil.getCurrentDbHostName(currentDB) + DbName + sql);

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
    }

    /**
        Send the User Id and new generated password to user via email
        Indicate success or failure
    */
    public void sendForgotEmail(String id,Date dob,String email,int type,String mainPageLink)
    throws SendIdPasswordException, DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        String userid=null,password=null,givenName,pid;
        String groupid="";
        String EMAIL_SUBJECT = "Your E-PaySlip user id and password";
        int SEND_USERID_ONLY = 1, SEND_PASSWORD_ONLY = 2;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);
        String sql = "";

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            //Operation sequence - Get User id and email address, Generate new password, update password, send email, update flag
            //Get user id and email address
            pstmt = conn.prepareStatement("SELECT surname,userid,given_name,p_id,group_id FROM user WHERE p_id=? AND dob=? AND email=?");

            pstmt.setString(1,id);
            //pstmt.setString(2,surname);
            pstmt.setDate(2,dob);
            pstmt.setString(3,email);

            ResultSet rs = pstmt.executeQuery();
            String surname = "";
            if(rs.next()) {
            	surname = rs.getString("surname");
                userid = rs.getString("userid");
                givenName = rs.getString("given_name");
                pid = rs.getString("p_id");
                groupid = rs.getString("group_id");
            }else
            {
                throw new SendIdPasswordException();
            }
            rs.close();

            PreparedStatement pstmt2;
            if (type != SEND_USERID_ONLY) {
                //Generate new password
                PasswordGenerator pg = new PasswordGenerator(8);
                String newpwd = pg.generate();

                pstmt2 = conn.prepareStatement("UPDATE user SET Password=? WHERE userid=?");

                Encryption encrypt = new Encryption();
                String enpwd = encrypt.getLock(newpwd);

                pstmt2.setString(1,enpwd);
                pstmt2.setString(2,userid);

                pstmt2.executeUpdate();
                pstmt2.close();
                password = newpwd;

                sql = "update user set password = '" + enpwd + "' where userid = '" + userid + "'";
                dbUtil.sqlToLogFile(dbUtil.getCurrentDbHostName(currentDB) + DbName + sql);
            }

            //Send the email
            ResourceBundle config = ResourceBundle.getBundle("SystemConfig");
            String smtpServer = config.getString("SMTP_SERVER");

            ResourceBundle comEmailConfig = ResourceBundle.getBundle("CompanyEmail");

            //Get the sender address
            groupid = groupid.toUpperCase();
            //String senderAddress = senderConfig.getString(groupid);
            // eg., PAYCITIHK_SEND_ADDRESS = password_reset@epayslip.com
            String senderAddress = config.getString(groupid + "_SEND_ADDRESS");
            String companyEmail = comEmailConfig.getString(groupid);

            String content = "";

            content += "Dear " + surname + " " + givenName + " (" + pid + "),\n\n";

            switch (type) {
            	// SEND_USERID_ONLY
                case 1 : EMAIL_SUBJECT = "Your E-PaySlip user id";
                         content += "Your user id      : " + userid + "\n\n";
                         break;
                // SEND_PASSWORD_ONLY
                case 2 : EMAIL_SUBJECT = "Your E-PaySlip password";
                         content += "Your password to view E-PaySlip has been reset.\n\n";
                         content += "Your new password : " + password + "\n\n";
                         break;
            }

            content += "You can login to E-PaySlip system here. " + mainPageLink + "\n\n";
            content += "If you have any enquiries regarding your E-PaySlip, please email to " + companyEmail + "\n\n";
            content += "Best Regards,\nE-PaySlip\n";

            try{
                Mailer m = new Mailer(smtpServer,senderAddress,email,EMAIL_SUBJECT,content);
                m.send();
            }catch(Exception e){

                throw new SendIdPasswordException();
            }

            //Update flag
            if (type != SEND_USERID_ONLY) {
                pstmt2 = conn.prepareStatement("UPDATE user SET reset_pwd='Y' WHERE userid=?");

                pstmt2.setString(1,userid);

                pstmt2.executeUpdate();
                pstmt2.close();

                sql = "update user set reset_pwd = 'Y' where userid = '" + userid + "'";
                dbUtil.sqlToLogFile(dbUtil.getCurrentDbHostName(currentDB) + DbName + sql);
            }
        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
            //throw new SendIdPasswordException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }

    }

    public boolean isUserFound(String id, Date dob, String email)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        boolean isExist = false;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);
        String sql = "";

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("SELECT p_id FROM user WHERE p_id=? AND dob=? AND email=?");

            pstmt.setString(1,id);
            //pstmt.setString(2,surname);
            pstmt.setDate(2,dob);
            pstmt.setString(3,email);

            ResultSet rs = pstmt.executeQuery();
            //pstmt.close();

            if (rs.next()) {
            	isExist = true;
            }
            rs.close();

            // update user's confirm email field.
            pstmt = conn.prepareStatement("update user set confirmemail=? WHERE p_id=? AND dob=?");

            pstmt.setString(1,email);
            pstmt.setString(2,id);
            //pstmt.setString(3,surname);
            pstmt.setDate(3,dob);

            pstmt.executeUpdate();

            sql = "update user set confirmemail = '" + email + "' where p_id = '" + id + "' and dob = '" + dob + "'";
            dbUtil.sqlToLogFile(dbUtil.getCurrentDbHostName(currentDB) + DbName + sql);

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }

        return isExist;
    }

    public void sendForgotAnswerEmail(String id, Date dob, String confirmemail, boolean isUserFound)
    throws SendIdPasswordException, DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        String givenName, answer, EMAIL_SUBJECT, groupid = "";
        EMAIL_SUBJECT = "Your E-PaySlip answer to secret question";
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            //Operation sequence - Get User id and email address, Generate new password, update password, send email, update flag
            //Get user id and email address
            pstmt = conn.prepareStatement("SELECT given_name,group_id,answer,surname FROM user WHERE p_id=? AND dob=? AND confirmemail=?");

            pstmt.setString(1,id);
            //pstmt.setString(2,surname);
            pstmt.setDate(2,dob);
            pstmt.setString(3,confirmemail);

            ResultSet rs = pstmt.executeQuery();
            String surname="";	
            if(rs.next()) {
                givenName = rs.getString("given_name");
                groupid = rs.getString("group_id");
                answer = rs.getString("answer");
                surname = rs.getString("surname");
            }else
            {
                throw new SendIdPasswordException();
            }
            rs.close();

            ResourceBundle config = ResourceBundle.getBundle("SystemConfig");
            ResourceBundle contactConfig = ResourceBundle.getBundle("TemPassword");

            String smtpServer = config.getString("SMTP_SERVER");
            String mainPageLink = config.getString("FIRSTPAGE_LINK");

            //Get the sender address
            groupid = groupid.toUpperCase();
            // eg., PAYCITIHK_SEND_ADDRESS = password_reset@epayslip.com
            String senderAddress = config.getString(groupid + "_SEND_ADDRESS");
            String helpEmail = contactConfig.getString(groupid + "_HELP_EMAIL");
            String helpLine = contactConfig.getString(groupid + "_HELP_LINE");

            String content = "";

            content += "Dear " + surname + " " + givenName + " (" + id + "),\n\n";
            if (isUserFound) {
                content += "Your answer to secret question : " + answer + "\n\n";
                content += "You can login to E-PaySlip system here. " + mainPageLink + "\n\n";
            }
            else {
                content += "The email address you have entered for retrieving your secret answer does not match with the email in our e-PaySlip system.\n";
                content += "Please re-try by entering your original pre-set email, or send an email to " + helpEmail + ". ";
            }
            content += "If you have further enquiries, please contact us at " + helpLine + " for further assistance.\n\n";
            content += "Best Regards,\nE-PaySlip\n";

            try{
                Mailer m = new Mailer(smtpServer,senderAddress,confirmemail,EMAIL_SUBJECT,content);
                m.send();
            }catch(Exception e){

                throw new SendIdPasswordException();
            }

        } catch (SQLException e1) {
            e1.printStackTrace();
            //throw new SendIdPasswordException();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
    }

    public boolean resetPassword(String userid)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        boolean result=false;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("SELECT reset_pwd FROM user WHERE userid=?");

            pstmt.setString(1,userid);

            ResultSet rs = pstmt.executeQuery();

            if(rs.next()) {
                String flag = rs.getString("reset_pwd");
                if(flag!=null)
                {
                    if(flag.equalsIgnoreCase("Y"))
                    {    result=true;    }
                }
            }
            rs.close();

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
        return result;

    }

    public void unsetResetPassword(String userid)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);
        String sql = "";

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();

            pstmt = conn.prepareStatement("UPDATE user SET reset_pwd=null WHERE userid=?");

            pstmt.setString(1,userid);

            pstmt.executeUpdate();

            sql = "update user set reset_pwd = null where userid = '" + userid + "'";
            dbUtil.sqlToLogFile(dbUtil.getCurrentDbHostName(currentDB) + DbName + sql);

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }

    }

    // modified 25Feb2008 by zhoukai
   /*    public Hashtable getUserInfoByPidAndClientid(String p_id,String clientName, boolean flag, HttpServletRequest request)
    																				throws DBAccessException*/
    																				
    public Hashtable getUserInfoByPidAndClientid(String user_id,String p_id,String clientName, boolean flag, HttpServletRequest request)
    	throws DBAccessException					
{
        Connection conn=null;
        PreparedStatement pstmt=null;
        Hashtable result = new Hashtable();
        ConnectionPool cp = new ConnectionPool();
        try {
            // Get a DB connection from the Broker
        	EpayslipUserList epayslipUserList = EPaySlipController.getEpayslipUserList();
        	
    		conn = cp.getConnection((String) request.getSession().getAttribute(Constant.POOL_NAME));
        	//conn = epayslipUserList.initConn(request);
    		
    		//Task ID: 5186  language data from session by Amit Kumar
    		String l = (String) request.getSession().getAttribute(User.LOCAL);
    		System.out.println("Session from code "+l);
    		if(l==null){
    			l="i18n_en";
    		}//end Task ID: 5186
        	if (conn == null) {
        		return null;
        	}
            
        	//===============================================================================================
            //amended by Julius.Liu on Nov 2007 for one login.
            /*  String sql = " SELECT * from users_epayslip where p_id=?";*/
        	String sql = " SELECT * from users_epayslip where user_id=?"; // insted of p_id  we added user_id
            pstmt = conn.prepareStatement(sql);
            // pstmt.setString(1,p_id);
            pstmt.setString(1,user_id);
            ResultSet rs = pstmt.executeQuery();

            if(rs.next()) {
            	result.put(LOGIN_GROUPID,rs.getString("group_id"));
                result.put(LOGIN_PID,p_id);
                result.put(LOGIN_PDAY,new Integer(rs.getInt("p_day")));
                result.put(LOGIN_EMPSTATUS,new Integer(rs.getInt("emp_status_epayslip")));
            } else {
            	//flag is a parameter expressing whether the 'p_id' is the login user. 
            	if (flag) {
            		return null;
            	}
            }

            //===============================================================================================
            //Data from pay_emp
            sql = " SELECT * from pay_emp where p_id=? and company = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1,p_id);
            pstmt.setString(2,clientName);
            rs = pstmt.executeQuery();
            
            if(rs.next()) {
            	result.put(LOGIN_SURNAME,rs.getString("surname"));
                result.put(LOGIN_GIVENNAME,rs.getString("given_name"));
                
                String dob = "";
                Date d = rs.getDate("dob");
                Calendar cal = Calendar.getInstance();
                cal.setTime(d);
                dob += ViewEventHandler.padChar(String.valueOf(cal.get(Calendar.DATE)),'0',2);
                dob += ViewEventHandler.padChar(String.valueOf(cal.get(Calendar.MONTH)+1),'0',2);
                dob += String.valueOf(cal.get(Calendar.YEAR));

                result.put(LOGIN_DOB,dob);

                String email = rs.getString("email");
                if (email == null) email = "";
                result.put(LOGIN_EMAIL,email);
            }
            //==============================================================================================
             result.put(LOCAL, l);
            
            rs.close();

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try {if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};
 
            try {
            	cp.closeConnection(conn);
            } catch (Exception ee) {
            	
            }
        }

        return result;
    }

    public Hashtable getUserInfo(String p_id, String group_id) throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        Hashtable result = new Hashtable();
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();
            
            pstmt = conn.prepareStatement("SELECT b.*,dob,surname,given_name,email FROM users a,users_epayslip b WHERE a.employee_id=b.p_id and employee_id=? and group_id=?");
            
            pstmt.setString(1,p_id);
            pstmt.setString(2,group_id);

            ResultSet rs = pstmt.executeQuery();
            if(rs.next()) {
            	result.put(LOGIN_GROUPID,rs.getString("group_id"));
                result.put(LOGIN_PID,rs.getString("p_id"));
                result.put(LOGIN_PDAY,new Integer(rs.getInt("p_day")));
                result.put(LOGIN_SURNAME,rs.getString("surname"));
                result.put(LOGIN_GIVENNAME,rs.getString("given_name"));

                String dob = "";
                Date d = rs.getDate("dob");
                Calendar cal = Calendar.getInstance();
                cal.setTime(d);
                dob += ViewEventHandler.padChar(String.valueOf(cal.get(Calendar.DATE)),'0',2);
                dob += ViewEventHandler.padChar(String.valueOf(cal.get(Calendar.MONTH)+1),'0',2);
                dob += String.valueOf(cal.get(Calendar.YEAR));

                result.put(LOGIN_DOB,dob);

                //Added on 29th April 2003 for super & root user access
                result.put(LOGIN_EMPSTATUS,new Integer(rs.getInt("emp_status_epayslip")));
                String email = rs.getString("email");
                if (email == null) email = "";
                result.put(LOGIN_EMAIL,email);
            }
            rs.close();
        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
        return result;

    }
    /*
    ==============================================================================
    								Written 17 March 2004
    ==============================================================================
    */
    public String GetGroupID(String p_id)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        ResultSet rs=null;
        String group_id="wrong";
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();
            //edited by Julius.Liu for eHR on 14 DEC 2006
//            pstmt = conn.prepareStatement("SELECT group_id FROM user WHERE p_id=?");
            pstmt = conn.prepareStatement("SELECT group_id FROM users a,users_epayslip b WHERE a.employee_id=b.p_id and employee_id=?");
            
            pstmt.setString(1,p_id);

            rs = pstmt.executeQuery();

            if(rs.next())
            	group_id = rs.getString("group_id");
            rs.close();

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
        return group_id;
    }
 	/*
    ==============================================================================
    								Written 18 March 2004
    ==============================================================================
    */
    public void setNextPasswordUpdate(String p_id, String p5,Date nextupdatepass)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);
        Encryption encrypt = new Encryption();
        String enpwd = encrypt.getLock(p5) , sql = "";;

        try {
            conn = dbMgr[currentDB].getConnection();
            pstmt = conn.prepareStatement("UPDATE password SET exp_date=? WHERE p_id=?");
            pstmt.setDate(1,nextupdatepass);
            pstmt.setString(2,p_id);
            pstmt.executeUpdate();
            sql = "update password set exp_date = " + nextupdatepass+ "where p_id = " + p_id ;
            dbUtil.sqlToLogFile(dbUtil.getCurrentDbHostName(currentDB) + DbName + sql);
        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
    }
    /*
    ==============================================================================
    								Written 18 March 2004
   					Check counter to monitor the check number in table Password
   ==============================================================================
    */
    public int getCheck(String p_id)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);
        ResultSet rs=null;
        int check=0;

        try {
           conn = dbMgr[currentDB].getConnection();
			pstmt = conn.prepareStatement("SELECT checkpass FROM password WHERE p_id=?");
            pstmt.setString(1,p_id);
            rs = pstmt.executeQuery();
            if(rs.next())
            	check= rs.getInt("checkpass");
            rs.close();
            check++;
            if(check==32)
            	check=1;
            return check;
        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};
            dbMgr[currentDB].freeConnection(conn);
        }
    }
	/*
    ==============================================================================
    								Written 18 March 2004
    				Update the check number and the password in table "Password"
    ==============================================================================
    */
    public void updatecheckpass(String p_id,int check,String p5)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);
        ResultSet rs=null;
        String passcolumn="pass";
        Encryption encrypt = new Encryption();
        String enpwd = encrypt.getLock(p5),sql="";

        try {
            conn = dbMgr[currentDB].getConnection();
			String a = new String();
            a = a.valueOf(check);
            passcolumn = passcolumn + a;
            pstmt = conn.prepareStatement("UPDATE password SET " + passcolumn + "=?, checkpass=? where p_id=?");
            pstmt.setString(1,enpwd);
            pstmt.setInt(2,check);
            pstmt.setString(3,p_id);
            pstmt.executeUpdate();
            sql = "update password set " + passcolumn + "=" + enpwd + ", checkpass=" + check + " where p_id="+p_id;
            dbUtil.sqlToLogFile(dbUtil.getCurrentDbHostName(currentDB) + DbName + sql);
        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};
            dbMgr[currentDB].freeConnection(conn);
        }
    }
/*================================================================
							Written on the 18 March 2004
			This is to ensure that there are no duplicate passwords in table "Password"
   ================================================================*/
	public boolean CheckDuplicatePassword(String p_id,String p5)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        int i,currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);
        ResultSet rs=null;
        Encryption test = new Encryption();
		String[] pass = new String[]{"","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","",""};
		boolean state = false;

        try {
            conn = dbMgr[currentDB].getConnection();
			pstmt = conn.prepareStatement("SELECT pass1,pass2,pass3,pass4,pass5,pass6,pass7,pass8,pass9,pass10,pass11,pass12,pass13,pass14,pass15,pass16,pass17,pass18,pass19,pass20,pass21,pass22,pass23,pass24,pass25,pass26,pass27,pass28,pass29,pass30,pass31,pass32 FROM password WHERE p_id=?");
            pstmt.setString(1,p_id);
            rs = pstmt.executeQuery();
            if(rs.next()){
            	pass[0]=rs.getString("pass1");
            	pass[1]=rs.getString("pass2");
            	pass[2]=rs.getString("pass3");
            	pass[3]=rs.getString("pass4");
            	pass[4]=rs.getString("pass5");
            	pass[5]=rs.getString("pass6");
            	pass[6]=rs.getString("pass7");
            	pass[7]=rs.getString("pass8");
            	pass[8]=rs.getString("pass9");
            	pass[9]=rs.getString("pass10");
            	pass[10]=rs.getString("pass11");
            	pass[11]=rs.getString("pass12");
            	pass[12]=rs.getString("pass13");
            	pass[13]=rs.getString("pass14");
            	pass[14]=rs.getString("pass15");
            	pass[15]=rs.getString("pass16");
            	pass[16]=rs.getString("pass17");
            	pass[17]=rs.getString("pass18");
            	pass[18]=rs.getString("pass19");
            	pass[19]=rs.getString("pass20");
            	pass[20]=rs.getString("pass21");
            	pass[21]=rs.getString("pass22");
            	pass[22]=rs.getString("pass23");
            	pass[23]=rs.getString("pass24");
            	pass[24]=rs.getString("pass25");
            	pass[25]=rs.getString("pass26");
            	pass[26]=rs.getString("pass27");
            	pass[27]=rs.getString("pass28");
            	pass[28]=rs.getString("pass29");
            	pass[29]=rs.getString("pass30");
            	pass[30]=rs.getString("pass31");
            	pass[31]=rs.getString("pass32");
            }
            rs.close();
			for(i=0;i<32;i++){
				if(test.getUnlock(pass[i]).compareTo(p5)==0){
					state=true;
					return state;
				}
			}
			return state;
        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};
            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
    }
    /*============================================================
    							Written 19 March 2004
       ============================================================*/
	public Date getPasswordDate(String p_id)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        Date Passdatee = null;
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();
            pstmt = conn.prepareStatement("SELECT exp_date FROM password WHERE p_id=?");
            pstmt.setString(1,p_id);
            ResultSet rs = pstmt.executeQuery();

            if(rs.next()){
                Date  Passdate = rs.getDate("exp_date");
                rs.close();
                dbMgr[currentDB].freeConnection(conn);
                return Passdate;
            }

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
        return Passdatee;
    }
    public String checkuserid(String userid)
    throws DBAccessException
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        String use="";
        int currentDB = CURRENT_DB = dbUtil.getCurrentDb(dbMgr, CURRENT_DB);

        try {
            // Get a DB connection from the Broker
            conn = dbMgr[currentDB].getConnection();
            pstmt = conn.prepareStatement("SELECT userid FROM user WHERE userid=?");
            pstmt.setString(1,userid);
            ResultSet rs = pstmt.executeQuery();

            if(rs.next()){
                use = rs.getString("userid");
            }
            rs.close();

        } catch (SQLException e1) {
            e1.printStackTrace();
            throw new DBAccessException();
    	} finally {
            try{if(pstmt != null) {pstmt.close();}} catch(SQLException e1){};

            // The connection is returned to the Broker
            dbMgr[currentDB].freeConnection(conn);
        }
        return use;
    }
}
