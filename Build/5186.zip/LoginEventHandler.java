package epayslip.system.event;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.ResourceBundle;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;

import sun.misc.BASE64Encoder;

import catalog.Catalog;
import catalog.constant.Constant;
import catalog.sso.GlobalSession;
import edu.yale.its.tp.cas.client.filter.CASFilter;
import epayslip.db.DBAccessException;
import epayslip.db.User;
import epayslip.db.init.ConnectionPool;
import epayslip.system.EPaySlipController;
import epayslip.utility.ConfigUtil;

public class LoginEventHandler extends EventHandler {

	private ResourceBundle bundle = ResourceBundle.getBundle("URLs");

	private static ResourceBundle comLogo = ResourceBundle
			.getBundle("CompanyLogo");

	private static ResourceBundle comEmail = ResourceBundle
			.getBundle("CompanyEmail");

	protected String getURL() {
		return bundle.getString("");
	}

public void process (ServletContext sc,
                       HttpServletRequest request, HttpServletResponse response)
    throws IOException, ServletException, DBAccessException {

        User usrMgr = EPaySlipController.getUserManager();

        // Detect which step in the flow
        String event = request.getParameter("event");

        if(event.equals("SSOLOGIN")) 
        {
        	HttpSession session = request.getSession();
        	String login_name = (String)session.getAttribute(CASFilter.CAS_FILTER_USER);
        	login_name = login_name.toUpperCase();
         	System.out.println("login_name in LoginEventHandler LNO 55  "+login_name);
            session.setAttribute(User.LOGIN_ID, login_name );
        	
        	GlobalSession gsession = new GlobalSession();
        	
    		String pid =(String)gsession.getAttribute(login_name,"P_ID");
	        System.out.println("pid in LoginEventHandler of epayslip LNO:60 "+pid);
    		session.setAttribute(User.LOGIN_PID, pid);
    		
    		Integer GLOBAL_ID =(Integer)gsession.getAttribute(login_name,"GLOBAL_ID");// added by shilpa.   user_id= 25839
    		String user_id= GLOBAL_ID.toString();
    		System.out.println("user_id in LoginEventHandler LNO:66 "+user_id);
    		session.setAttribute(User.LOGIN_USERID, user_id);
    		
    		String client_name = (String)gsession.getAttribute(login_name, "CLIENT_NAME" );        //TNL
    		System.out.println("in LoginEventHandler LNO 70 client_name: "+client_name);
            session.setAttribute(User.LOGIN_COMID, client_name );
    		
    		String sur =(String)gsession.getAttribute(login_name,"SURNAME");
    		session.setAttribute(User.LOGIN_SURNAME, sur);
    		
    		String given = (String)gsession.getAttribute(login_name, "GIVEN_NAME" );
    		session.setAttribute(User.LOGIN_GIVENNAME, given );
    		
    		String epayslip_db = (String)gsession.getAttribute(login_name, "EPAYSLIP_DB" );
	        System.out.println("epayslip db connection : "+epayslip_db);
    		session.setAttribute(Constant.POOL_NAME, epayslip_db );
    		
    		//when the login user have not access to epayslip module
            /*boolean result = storeLoginInformation(usrMgr, request.getSession(), pid, client_name, request);*/
            
            boolean result = storeLoginInformation(usrMgr, request.getSession(), user_id, pid, client_name, request);
             if (result==false){
            	request.setAttribute("FORWARD_URL", "NO_ACCESS");
            	return;
            }

     // added from here tejaswi 
            
            pid=getpid_epayslip(user_id,epayslip_db);
            if(pid!=null){
            session.setAttribute(User.LOGIN_PID, pid);                               //updating empid for Account Linkup
            System.out.println("after updating the empid is session for account Linkup LNO:105 ");
            } 
            pid =(String)session.getAttribute(User.LOGIN_PID);
           // pid=empid;
           // Added on 29th April 2003 for super & root user access
            /*Hashtable ht = usrMgr.getUserInfoByPidAndClientid( pid, client_name, true, request);*/
            
            Hashtable ht = usrMgr.getUserInfoByPidAndClientid( user_id,pid, client_name, true, request);
            int userType = ((Integer)ht.get(User.LOGIN_EMPSTATUS)).intValue();

            /*String groupId = null;
            if (userType == User.SUPER_USER) groupId = (String)ht.get(User.LOGIN_GROUPID);
            else if (userType == User.GROUP_USER) groupId = (String)ht.get(User.LOGIN_LOCATION);*/

            if (userType == User.ROOT_USER || userType == User.SUPER_USER ||
                userType == User.GROUP_USER) {
                //HttpSession session = request.getSession();
            	/*Vector comList = usrMgr.getCompanyList(groupId, request);
            	session.setAttribute("COMPANY_LIST", comList);
            	Vector userList = usrMgr.getAllUserList(groupId, comList);
            	session.setAttribute("USER_LIST", userList);*/

                request.setAttribute("FORWARD_URL", "POWERUSER_MENU");
            } else {
            	String groupid = (String)session.getAttribute(User.LOGIN_GROUPID);
            	String cmonth = (String) session.getAttribute("currentmonth");
            	if(groupid.equals("EMP_USER")){
            		Calendar cal = Calendar.getInstance();
            		int year = cal.get(Calendar.YEAR);
            		int month = cal.get(Calendar.MONTH)+1;
            		if(cmonth==null){
            			boolean html_pdf = ConfigUtil.getPdfFlag(new Integer(year).toString(), new Integer(month).toString(), request);
            			if(html_pdf){
            				
	            			String sm = new Integer(month).toString();
	            			if(sm.length()==1)
	            				sm = "0"+sm;
		            		String dummyStr = encript(pid+","+year+","+sm+","+1);
		            		request.setAttribute("DUMMYSTR", "PdfView?link="+dummyStr);
		            		
		            		//added by kevin for MPF/ORSO Advice Form on 9Feb 2011 start 
            				String root, fullPath = "", sep, fileName = "";
                			sep = File.separator; // platform dependent file separator
                			root = EPaySlipController.getDocRoot(); // Get the root directory
                			if (!root.substring(root.length() - 1).equals(File.separator)) {
                				root = root + File.separator;
                			}
                			String dob = (String)ht.get("LOGIN_DOB");
                			fileName = "MPF_ORSO_" + pid + "_" + dob+ "_" + year + "_" + sm + ".pdf";
                			fullPath = root + client_name + sep + year + sep + sm + sep + "MPF_ORSO" + sep + fileName;
                			File adviceFile = new File(fullPath + ".encrypted");
                			if(adviceFile.exists()){
                				String dummyAdvice = encript(pid+","+year+","+sm);
                				request.setAttribute("DUMMYADVICE", "AdviceView?link=" + dummyAdvice);
                			}
                			//added by kevin 9Feb 2011 end
	            		}
            		}else if(cmonth.equals(new Integer(month).toString())){
	            		boolean html_pdf = ConfigUtil.getPdfFlag(new Integer(year).toString(), new Integer(month).toString(), request);
	            		if(html_pdf){
	            			String sm = new Integer(month).toString();
	            			if(sm.length()==1)
	            				sm = "0"+sm;
		            		String dummyStr = encript(pid+","+year+","+sm+","+1);
		            		request.setAttribute("DUMMYSTR", "PdfView?link="+dummyStr);
		            		
		            		//added by kevin for MPF/ORSO Advice Form on 9Feb 2011 start 
            				String root, fullPath = "", sep, fileName = "";
                			sep = File.separator; // platform dependent file separator
                			root = EPaySlipController.getDocRoot(); // Get the root directory
                			if (!root.substring(root.length() - 1).equals(File.separator)) {
                				root = root + File.separator;
                			}
                			String dob = (String)ht.get("LOGIN_DOB");
                			fileName = "MPF_ORSO_" + pid + "_" + dob+ "_" + year + "_" + sm + ".pdf";
                			fullPath = root + client_name + sep + year + sep + sm + sep + fileName;
                			File adviceFile = new File(fullPath + ".encrypted");
                			if(adviceFile.exists()){
                				String dummyAdvice = encript(pid+","+year+","+sm);
                				request.setAttribute("DUMMYADVICE", "AdviceView?link=" + dummyAdvice);
                			}
                			//added by kevin 9Feb 2011 end
	            		}
            		}
            	}
                request.setAttribute("FORWARD_URL", "USER_MENU"); // default
                /*// Added on 6th August 2003 for periodical email update
            	String email = (String)ht.get(User.LOGIN_EMAIL);
            	Date nextEmailUpdatePromptDate = (Date)ht.get(User.LOGIN_NEXTEMAILUPDATEPROMPTDATE);
            	Date todaysDate = new Date();

				// ==============================================================================
				// Written on the 19 March 2004
				// When password expires for HSBCSG, it will ask for user to key in new
				// password
				// ==============================================================================
				SimpleDateFormat abc = new SimpleDateFormat("yyyy-MM-dd");
				Date aaa = new Date();
				String d = abc.format(aaa).toString();
				String grp =usrMgr.GetGroupID(ht.get(User.LOGIN_PID).toString(), request);
				String e = "";
				if( grp.equals("HSBCSG"))
					e =usrMgr.getPasswordDate(ht.get(User.LOGIN_PID).toString()).toString();
				if((d.compareTo(e))>=0 && grp.equals("HSBCSG"))
					request.setAttribute("FORWARD_URL", "LOGIN_CHANGEPASSWORD_HSBCSG");
                    // ============================================================================
					//		commented by Julius.Liu for eHR on 14 DEC 2006
					//        if (!email.equals("") && (todaysDate.compareTo(nextEmailUpdatePromptDate) >=0)) {
					//                        request.setAttribute("FORWARD_URL", "EMAIL_UPDATE");
					//                    }
					// Added on 26th November 2003 for paysun add secret answer
                groupId = (String)ht.get(User.LOGIN_GROUPID);
                if (groupId.equalsIgnoreCase("PAYSUN")) {
                    String answer = (String)ht.get(User.LOGIN_ANSWER);
                    if (answer != null && answer.equals("")) {
                        request.setAttribute("FORWARD_URL","NEWUSER_DISPLAYQUESTION");
                    }
                }*/
            }
        }
        else if(event.equals("LOGIN_POWERUSER")) // poweruser viewing normal user's epayslip
    	{
            HttpSession session = request.getSession();

            String p_id = request.getParameter("p_id");
            String group_id = request.getParameter("group_id");
            Hashtable ht = usrMgr.getUserInfo(p_id, group_id);

            session.setAttribute(User.LOGIN_GROUPID, ht.get(User.LOGIN_GROUPID));
            //edited by Julius.Liu for eHR on 14 DEC 2006
            //session.setAttribute(User.LOGIN_COMID,(String)ht.get(User.LOGIN_COMID));
            session.setAttribute(User.LOGIN_PID, ht.get(User.LOGIN_PID));
            session.setAttribute(User.LOGIN_PDAY, ht.get(User.LOGIN_PDAY));
            session.setAttribute(User.LOGIN_SURNAME, ht.get(User.LOGIN_SURNAME));
            session.setAttribute(User.LOGIN_GIVENNAME, ht.get(User.LOGIN_GIVENNAME));
            session.setAttribute(User.LOGIN_DOB, ht.get(User.LOGIN_DOB));

            String sLink="";
            String groupId = (String)ht.get(User.LOGIN_GROUPID);
            groupId = groupId.toUpperCase();

            try{
                sLink = comLogo.getString(groupId);
            }catch(Exception e1){System.out.println(e1);}// if could not find
															// key, throw
															// exception

            String email="";
            try{
                email = comEmail.getString(groupId);
            }catch(Exception e1){System.out.println(e1);}// if could not find
															// key, throw
															// exception

            session.setAttribute("LOGO_LINK",sLink);
            session.setAttribute("COMPANY_EMAIL",email);

            request.setAttribute("FORWARD_URL", "USER_MENU");

    	}
    }	

	public void forward(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		String key = (String) request.getAttribute("FORWARD_URL");
		request.removeAttribute("FORWARD_URL");
		if (key == null)
			key = "";
		RequestDispatcher rd = request.getRequestDispatcher(bundle
				.getString(key));
		rd.forward(request, response);
	}

/*	public static boolean storeLoginInformation(User usrMgr, HttpSession session,
												String p_id, String client_name, HttpServletRequest request) throws DBAccessException {*/
		
		public static boolean storeLoginInformation(User usrMgr, HttpSession session,
				String user_id,String p_id, String client_name, HttpServletRequest request) throws DBAccessException {
			
		
		
		/*Hashtable ht = usrMgr.getUserInfoByPidAndClientid(p_id, client_name, true, request);*/
		Hashtable ht = usrMgr.getUserInfoByPidAndClientid(user_id,p_id, client_name, true, request);
		
		if (ht==null || ht.size()==0){
			//JY:Redirect user back to portal
			return false;
		}

		session.setAttribute(User.LOGIN_GROUPID, ht.get(User.LOGIN_GROUPID));
		//session.setAttribute(User.LOGIN_COMID, ht.get(User.LOGIN_COMID));
		//session.setAttribute(User.LOGIN_PID, ht.get(User.LOGIN_PID));
		session.setAttribute(User.LOGIN_PDAY, ht.get(User.LOGIN_PDAY));
		//session.setAttribute(User.LOGIN_SURNAME, ht.get(User.LOGIN_SURNAME));
		//session.setAttribute(User.LOGIN_GIVENNAME, ht.get(User.LOGIN_GIVENNAME));
		session.setAttribute(User.LOGIN_DOB, ht.get(User.LOGIN_DOB));

		// Added on 29th April 2003 for super & root user access
		session.setAttribute(User.LOGIN_EMPSTATUS, ht.get(User.LOGIN_EMPSTATUS));

		// Added on 6th August 2003 for periodical email update
		session.setAttribute(User.LOGIN_EMAIL, ht.get(User.LOGIN_EMAIL));
		session.setAttribute(User.LOCAL, ht.get(User.LOCAL)); //Amit Kumar 08-09-15 Task ID: 5186

		String sLink = "";
		String groupId = (String) ht.get(User.LOGIN_GROUPID);
		groupId = groupId.toUpperCase();

		try {
			sLink = comLogo.getString(groupId);
		} catch (Exception e1) {
			System.out.println(e1);
		}// if could not find key, throw exception

		session.setAttribute("LOGO_LINK", sLink);
		
		return true;
	}
	
	private static String encript(String year) {
		String ret = "";
		String str = year;
		BASE64Encoder encode = new BASE64Encoder();
		try {
			ret = encode.encode(str.getBytes("utf-8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return ret;
	}
public String getpid_epayslip(String userid,String epayslip_db){
		 ConnectionPool cp = new ConnectionPool();
         Connection con=null;
         PreparedStatement pstmt=null;
         //Statement stmt = null;
 		   ResultSet rs = null;
 		   String empid=null;
         String sql="select p_id from users_epayslip where user_id='"+userid+"'";
          try{
        	  con = cp.getConnection(epayslip_db);
        	  System.out.println("connection of epayslip is LoginEventHandler Lno: 391 "+con);
        	  pstmt = con.prepareStatement(sql);  
        	  rs = pstmt.executeQuery();
          if(rs.next()){
          	 empid=rs.getString("p_id");
          }
          rs.close();
          }catch(Exception e){
          	e.printStackTrace();
          }finally{
          	try{
          		  if(pstmt!=null){
          		   pstmt.close(); 
          		  }if(con!=null){
          			con.close();
          		   }
          	   }catch(Exception e){
          		e.printStackTrace();
          	}
          	}
          System.out.println("in getpid_epayslip empid before return from method "+empid);
          return empid;
          }
}
