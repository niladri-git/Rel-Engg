package epayslip.system.event;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.ResourceBundle;
import java.util.Vector;

import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
import epayslip.db.FileEncryption;
import epayslip.db.User;
import epayslip.system.EPaySlipController;
import epayslip.utility.ConfigUtil;

public class ViewEventHandler_pdf extends HttpServlet {

	public final static int BUF_SIZE = 500;

	private ResourceBundle bundle = ResourceBundle.getBundle("URLs");

	protected String getURL() {
		return bundle.getString("");
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		HttpSession session = request.getSession();
		// Directory format - group id, year, month, file
		// User file format - Empid_Surname_DOB_year_mth_X.html
		// X is the sequence number, there might be multiple page

		// Get all the required information
		// Date d;
		Calendar cal = Calendar.getInstance();
		String currentMonth = String.valueOf(cal.get(Calendar.MONTH) + 1); // Added
		//---------------------// amit Task ID: 5186
		String localLan = (String)request.getSession().getAttribute(User.LOCAL); 
		ResourceBundle rb = ResourceBundle.getBundle(localLan);
		//response.setCharacterEncoding("UTF-8"); 
		//------------- ended 
		// 08-Sep-2003
		if (currentMonth.length() == 1)
			currentMonth = "0" + currentMonth; // Added 08-Sep-2003
		String groupId, comId, empId, year, month, dob = "", client_name;
		int seq = 0, nopage = 0, curpage = 1;

		dob = (String) session.getAttribute(User.LOGIN_DOB);
		client_name = (String) session.getAttribute(User.LOGIN_COMID);
		// cal.setTime(d);
		// dob += padChar(String.valueOf(cal.get(Calendar.DATE)),'0',2);
		// dob += padChar(String.valueOf(cal.get(Calendar.MONTH)+1),'0',2);
		// dob += String.valueOf(cal.get(Calendar.YEAR));

		groupId = (String) session.getAttribute(User.LOGIN_GROUPID);
		request.setAttribute("GROUP_ID_OF_LOGIN", groupId);
		comId = (String) session.getAttribute(User.LOGIN_COMID);
		empId = (String) session.getAttribute(User.LOGIN_PID);
        String user_id = (String) session.getAttribute(User.LOGIN_USERID);
		int userType = ((Integer) session.getAttribute(User.LOGIN_EMPSTATUS))
				.intValue();
		year = request.getParameter("year");
		month = request.getParameter("month");
		int pageOfnow = 0;
		String checkIfLogin = request.getParameter("link");
		if (checkIfLogin != null) {
			checkIfLogin = decrypt(checkIfLogin);
			String[] dummyArr = checkIfLogin.split(",");
			empId = dummyArr[0];
			year = dummyArr[1];
			month = dummyArr[2];
			pageOfnow = Integer.parseInt(dummyArr[3]);
			try {
				// append for ee view 
				if(groupId.equals("EMP_USER")){
					empId = (String) session.getAttribute(User.LOGIN_PID);
				}//end
				User usrMgr = EPaySlipController.getUserManager();
				/*
				 * Hashtable ht = usrMgr.getUserInfoByPidAndClientid(empId,
				 * client_name, false, request);
				 */
				Hashtable ht = usrMgr.getUserInfoByPidAndClientid(user_id,
						empId, client_name, false, request);

            	dob = ((String) ht.get(User.LOGIN_DOB));
				groupId = "EMP_USER";

				userType = 1;// ((Integer)ht.get(User.LOGIN_EMPSTATUS)).intValue();

			} catch (Exception e) {
				System.out.println(e);
			}
		}

		// JY: Stores in Session, so that user can click back
		// and still see the previous selection
		session.setAttribute("currentyear", year);
		session.setAttribute("currentmonth", month);

		String root, fullPath = "", sep, fileName = "";
		sep = File.separator; // platform dependent file separator
		
		boolean html_pdf = ConfigUtil.getPdfFlag(year, month, request);

		root = EPaySlipController.getDocRoot(); // Get the root directory
		
		if (!root.substring(root.length() - 1).equals(File.separator)) {
			root = root + File.separator;
		}

		if (month.length() == 1) {
			month = "0" + month;
		}
		// Check how many pages available
		String fnStart, fnEnd; // file name start and end
		if (groupId != null
				&& (groupId.equals("PAYSMU") || groupId.equals("PAYKRAFT")
						|| groupId.equals("PAYFUSION")
						|| groupId.equals("PAYBENQ") || groupId
						.equals("PAYABFOOD")))
			fnStart = empId + "_" + dob + "_" + year + "_" + month + "_";
		else
			// comment by Julius.Liu on Jun 2007
			// fnStart = comId + "_" + empId + "_" + dob + "_" + year + "_" +
			// month + "_";
			fnStart = empId + "_" + dob + "_" + year + "_" + month + "_";
		// fnEnd = ".html";
		if (html_pdf) {
			fnEnd = ".pdf";
		} else {
			fnEnd = ".html";
		}

		fileName = fnStart + String.valueOf(seq + 1) + fnEnd;

		Vector v = new Vector();
		// v.add(String.valueOf(seq));
		Vector t = new Vector();
		// t.add(String.valueOf(seq));
		// int countt=1;
		int countt = 0;

		// Added on 8th September 2003, to cater for holding release of epayslip
		// html files
		if (userType == User.ROOT_USER || userType == User.SUPER_USER) {
			File epayslipPath;
			if (currentMonth.equals(month)) {
				epayslipPath = new File(root + groupId + sep + year + sep
						+ month);
				System.out.println("OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO    "
						+ epayslipPath);
				if (!epayslipPath.exists()) {
					month += "-temp";
				}
			}
		}

		while (countt < 100) {
			seq++;
			countt++;
			String nextFn = fnStart + String.valueOf(seq) + fnEnd;
			fullPath = root + groupId + sep + year + sep + month + sep + nextFn;
			File fChk = new File(fullPath);
			if (fChk.exists()) {
				v.add(String.valueOf(seq));
				t.add(String.valueOf(countt));
				nopage++;
				// if epayslip does not start with batch 1, designate 1st batch
				// as page 1
				if (nopage == 1)
					fileName = fnStart + String.valueOf(seq) + fnEnd;
			}
		}

		// End check how many pages

		// Check whether which page the user wants
		String offset = request.getParameter("offset");
		if (offset != null) {
			fileName = fnStart + offset + fnEnd;
			curpage = Integer.parseInt(offset);
			// corpg = t.indexOf(offset.toString());

			// curpage = v.elementAt(Integer.valueOf(corpg));
			// curpage = Integer.parseInt((String)v.elementAt(corpg));
		}

		// Generate the full path name
		fullPath = root + comId + sep + year + sep + month + sep + fileName;
		File f = new File(fullPath);

		// =================================================================================================
		// Encryption of file technique added by alex on sep 2005
		// if(groupId!=null &&
		// (groupId.equals("PAYDEMO")||groupId.equals("PAYSMU")||groupId.equals("PAYFUSION")||groupId.equals("PAYKRAFT")||groupId.equals("PAYBENQ")||groupId.equals("PAYABFOOD"))){
		File enFile = new File(fullPath + ".encrypted");
		response.setCharacterEncoding("UTF-8");
		ServletOutputStream outpdf = response.getOutputStream();
		if (enFile.exists()) {
			try {
				String osName = java.lang.System.getProperty("os.name");
				File ff = null;
				if (osName.indexOf("Windows") >= 0) {
					ff = new File("E:/Tomcat5.5/fileencryptionkey.key");
					// test
				} else {
					ff = new File("/usr/local/tomcat/bin/fileencryptionkey.key");
				}
				DataInputStream in = new DataInputStream(
						new FileInputStream(ff));
				byte[] rawkey = new byte[(int) ff.length()];
				in.readFully(rawkey);
				in.close();
				// Convert the raw bytes to a secret key like this
				DESedeKeySpec keyspec = new DESedeKeySpec(rawkey);
				SecretKeyFactory keyfactory = SecretKeyFactory
						.getInstance("DESede");
				SecretKey key = keyfactory.generateSecret(keyspec);
				FileEncryption fileEncryption = new FileEncryption(key);
				InputStream inpdf = fileEncryption.decrypt(new FileInputStream(
						f.getPath() + ".encrypted"));
				int numRead = 0;
				if (html_pdf) {
					response.setContentType("application/pdf");
				} else {
					response.setContentType("text/html");
				}

				byte[] buf = new byte[1024];
				while ((numRead = inpdf.read(buf)) >= 0) {
					outpdf.write(buf, 0, numRead);
				}

				response.setContentLength(buf.length);
				outpdf.close();
			} catch (Exception ee) {
				ee.printStackTrace();
			}
		}

		if (!f.exists()) // File does not exist, prompt for error
		{

			StringBuffer html = new StringBuffer();
			PrintWriter writer = new PrintWriter(new OutputStreamWriter(outpdf, "utf-8")); //amit kumar Task ID : 5168 added UTF-8 for chines 15-09-15
			html.append("<html>");
			html.append("<head>");
			//html.append("<title>ePayslip</title>"); 
			html.append("<title>"+ rb.getString("ePayslip.title") + "</title>");
			html.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">");
			html.append("<link rel=\"stylesheet\" href=\"/epayslip/bg.css\" type=\"text/css\">");
			html.append("<link rel=\"stylesheet\" href=\"/epayslip/text.css\" type=\"text/css\">");
			html.append("<style>");
			html.append("A:link {text-decoration:none; color:#FF9900; }");
			html.append("A:visited {text-decoration:none; color:#FF9900; }");
			html.append("A:hover	{text-decoration:none; color:#bbbbbb}");
			html.append("</style>");
			html.append("</head>");
			html.append("<script type=\"text/javascript\">");
			html.append("function this_close() {");
			html.append("    this.close();");
			html.append("}");
			html.append("</script>");
			html.append("<body bgcolor=\"#FFFFFF\" text=\"#000000\" class=\"BG\">");
			html.append("<div align=\"center\">");
			html.append("  <table width=\"610\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" height=\"92\">");
			html.append("    <tr>");
			html.append("      <td width=\"155\"><img src=\"/epayslip/images/epaysmal.gif\" width=\"146\" height=\"92\"></td>");
			html.append("    </tr>");
			html.append("  </table>");
			html.append("  <p>&nbsp;</p>");
			html.append("  <table width=\"600\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\" height=\"40\">");
			html.append("    <tr>");
			
		//	html.append("      <td background=\"/epayslip/images/blank_bar.gif\" valign=\"bottom\"><font color=\"#FFFFFF\" face=\"Arial, Helvetica, sans-serif\" size=\"3\"><b>FILE  ");
			html.append("      <td background=\"/epayslip/images/blank_bar.gif\" valign=\"bottom\"><font color=\"#FFFFFF\" face=\"Arial, Helvetica, sans-serif\" size=\"3\"><b>" + rb.getString("epayslip.file") + "  ");
			
			//html.append("        </b>NOT FOUND</font></td>");
			html.append("        </b>" + rb.getString("epayslip.not.found") + "</font></td>");
			
			html.append("    </tr>");
			html.append("  </table>");
			html.append("  <table width=\"600\" border=\"0\" cellspacing=\"1\" cellpadding=\"5\" bgcolor=\"#999999\">");
			html.append("    <tr> ");
			
			//html.append("      <td bgcolor=\"#bbbbbb\" valign=\"bottom\" height=\"44\">The requested e-PaySlip file could not be found on the server.</td>"); 
			html.append("      <td bgcolor=\"#bbbbbb\" valign=\"bottom\" height=\"44\">" + rb.getString("when.server.dont.have.epayslip") + " </td>");
			
			html.append("    </tr>");
			html.append("    <tr>");
			html.append("      <td bgcolor=\"#dddddd\" valign=\"bottom\">");
			html.append("        <div align=\"center\">");
			html.append("          <p>&nbsp;</p>");
			html.append("          <p>&nbsp;</p>");
			html.append("        </div>");
			html.append("      </td>");
			html.append("    </tr>");
			html.append("  </table>");
			html.append("  <table width=\"600\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" height=\"23\" background=\"/epayslip/images/bottbar.gif\">");
			html.append("    <tr>");
			//html.append("      <td align=\"right\"><a href=\"javascript:this_close();\"><b>CLOSE ME</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>"); 
			html.append("      <td align=\"right\"><a href=\"javascript:this_close();\"><b>" + rb.getString("epayslip.cliseme.button") + "</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>");
			html.append("      </td>");
			html.append("    </tr>");
			html.append("  </table>");
			html.append("  <br>");
			html.append("  <table width=\"320\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" height=\"60\">");
			html.append("    <tr> ");
			html.append("      <td width=\"90\" align=\"center\" height=\"64\"><img src=\"/epayslip/images/epaysmall2.gif\" width=\"82\" height=\"31\"></td>");
			html.append("      <td width=\"230\" align=\"center\" height=\"64\"><font size=\"1\">&#149; &nbsp; ");
			
	        SimpleDateFormat df=new SimpleDateFormat("yyyy");
	        String curyear=df.format(new Date());

			//html.append("         &copy; "+curyear+" i-Admin. All rights reserved.</font></td>");
			html.append("         &"+ rb.getString("epayslip.iadmin.copay") + "; "+curyear+" "+ rb.getString("epayslip.iadmin.all.rights.reserved") + "</font></td>");
			
			html.append("    </tr>");
			html.append("  </table>");
			html.append("</div>");
			html.append("</body>");
			html.append("</html>");
			
			response.setContentType("text/html;charset=utf-8");
			response.setHeader("Pragma", "no-cache");
			response.setHeader("Cache-Control", "no-cache");
			response.setDateHeader("Expires", 0);
			
			//outpdf.write(html.toString().getBytes());
			//outpdf.close();
             writer.print(html);			
			 writer.close();

		} else {
			byte[] buf;
			int byteRead;
			String searchEmpid;

			try {
				/*
				 * change13Oct2002 response.setContentType("text/html");
				 * 
				 * ServletOutputStream sos = response.getOutputStream();
				 * BufferedOutputStream bos = new BufferedOutputStream(sos);
				 */

				// Read the file into buffer
				FileInputStream in = new FileInputStream(f);

				buf = new byte[(int) f.length()];
				byteRead = in.read(buf, 0, buf.length);

				// Search for the empid in the file
				searchEmpid = new String(buf);

				// JY: Safeguard
				// if(searchEmpid.indexOf(empId)== -1) //not found
				if (false) // not found
				{
					request.setAttribute("message",
									"The requested e-PaySlip file is invalid. Please contact your administrator.");
					request.setAttribute("FORWARD_URL", "VIEW_FILEINVALID");
					request.setAttribute("EPAYSLIP_YEAR", year);
					request.setAttribute("EPAYSLIP_MONTH", month);
					request
							.setAttribute("BACKTHISPAGE",
									new Integer(pageOfnow));
				} else {
					/*
					 * change13Oct2002 sos.write(buf,0,buf.length);
					 * 
					 * //Print page number at bottom String pgno = "<div
					 * align=\"center\">Page : "; int temp=0; for(int i=0;i<nopage;i++) {
					 * if(curpage==i+1) { pgno += String.valueOf(temp+1) + "
					 * &nbsp;&nbsp;"; temp++; } else pgno += "<a
					 * href=\"/epayslip/servlet/EPSController?event=VIEW_PAYSLIP&year="+year+"&month="+month+"&offset="+String.valueOf(i+1)+"\">" +
					 * String.valueOf(i+1) + " </a>&nbsp;&nbsp;"; } pgno += "</div><br>";
					 * sos.write(pgno.getBytes());
					 * 
					 * //Print the back button at the bottom??? //<div
					 * align="center"><a href="javascript:history.back()"><img
					 * src="/epayslip/images/P_back.gif" width="74" height="19"
					 * border="0"></a></div> //<a
					 * href="/epayslip/servlet/EPSController?event=LOGOUT"><img
					 * src="/epayslip/images/P_logoutb.gif" width="71"
					 * height="19" border="0"></a> String back = ""; back += "<div
					 * align=\"center\"><a href=\"javascript:history.back()\"><img
					 * src=\"/epayslip/images/P_back.gif\" width=\"74\"
					 * height=\"19\" border=\"0\"></a><a
					 * href=\"/epayslip/servlet/EPSController?event=LOGOUT\"><img
					 * src=\"/epayslip/images/P_logoutb.gif\" width=\"71\"
					 * height=\"19\" border=\"0\"></a></div>\n";
					 * sos.write(back.getBytes());
					 * 
					 * bos.flush(); in.close(); bos.close();
					 */

					/*
					 * change13Oct2002 forward the response printing to jsp page -
					 * epayslip.jsp
					 */
					in.close();
					request.setAttribute("EPAYSLIP_DOC", buf);
					request.setAttribute("EPAYSLIP_NOPAGES",
							new Integer(nopage));
					request.setAttribute("EPAYSLIP_CURPAGE", new Integer(
							curpage));
					request.setAttribute("EPAYSLIP_YEAR", year);
					request.setAttribute("EPAYSLIP_MONTH", month);
					request
							.setAttribute("BACKTHISPAGE",
									new Integer(pageOfnow));
					request.setAttribute("EPAYSLIP_PAGES", v);
					// haibo.tan add by 2007.7.2
					request.setAttribute("logo_img", comId + ".gif");
					// end

					request.setAttribute("FORWARD_URL", "VIEW_EPAYSLIP");
					// f.deleteOnExit();
					File df = new File(fullPath);
					df.delete();

				}

			} catch (IOException e) {
				e.printStackTrace();
				request.setAttribute("FORWARD_URL", "VIEW_FILEREADERROR");
			}

		}// end if file exists

	}

	public void forward(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		String key = (String) request.getAttribute("FORWARD_URL");
		request.removeAttribute("FORWARD_URL");
		if (key == null)
			key = "";

		if (!key.equals("VIEW_NOFORWARD")) {
			RequestDispatcher rd = request.getRequestDispatcher(bundle
					.getString(key));
			rd.forward(request, response);
		}

	}

	public static String padChar(String str, char c, int l) {
		int len = str.length();
		if (l <= len)
			return str;
		else
			return spaces(c, l - len) + str;
	}

	public static String spaces(char c, int v) {
		if (v <= 0)
			return "";
		else
			return c + spaces(c, v - 1);
	}

	private static String decrypt(String input) {
		String output = "";
		try {
			BASE64Decoder decode = new BASE64Decoder();
			output = new String(decode.decodeBuffer(input), "utf-8");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return output;
	}

	private static String encript(String year) {
		String ret = "";
		String str = year;
		BASE64Encoder encode = new BASE64Encoder();
		try {
			ret = encode.encode(str.getBytes("utf-8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return ret;
	}

	public static void main(String[] args) {
		String fluker = "100001,2008,03";
		fluker = encript(fluker);
		System.out.println(fluker);
		String outstr = decrypt(fluker);
		String[] str = outstr.split(",");
		for (Object out : str) {
			String obj = (String) out;
			System.out.println(obj);
		}
	}
}
